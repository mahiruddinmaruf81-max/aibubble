package com.maruf.aibubble;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Phone-er bhitore (offline) chhobi theke Chinese / English lekha khoja, ar seguli translate. */
public final class Ocr {

    private Ocr() {}

    public static final class Item {
        public final Rect box;
        public final String text;
        public volatile String translated;

        Item(Rect box, String text) {
            this.box = box;
            this.text = text;
        }
    }

    public interface Callback {
        /** Main thread-e ashe. */
        void onResult(List<Item> items, Exception error);
    }

    private static TextRecognizer recognizer;

    private static synchronized TextRecognizer get() {
        if (recognizer == null) {
            recognizer = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        }
        return recognizer;
    }

    /** Block (paragraph) hishebe lekha. Lens-er jonno. */
    public static void blocks(Bitmap bm, Callback cb) {
        run(bm, false, cb);
    }

    /** Line hishebe lekha. Chat screen porar jonno. */
    public static void lines(Bitmap bm, Callback cb) {
        run(bm, true, cb);
    }

    private static void run(Bitmap bm, boolean byLine, Callback cb) {
        try {
            get().process(InputImage.fromBitmap(bm, 0))
                    .addOnSuccessListener(t -> {
                        List<Item> out = new ArrayList<>();
                        for (Text.TextBlock b : t.getTextBlocks()) {
                            if (byLine) {
                                for (Text.Line l : b.getLines()) add(out, l.getBoundingBox(), l.getText());
                            } else {
                                add(out, b.getBoundingBox(), b.getText().replace('\n', ' '));
                            }
                        }
                        Collections.sort(out, (a, c) -> a.box.top != c.box.top
                                ? Integer.compare(a.box.top, c.box.top) : Integer.compare(a.box.left, c.box.left));
                        cb.onResult(out, null);
                    })
                    .addOnFailureListener(e -> cb.onResult(new ArrayList<>(), e));
        } catch (Exception e) {
            cb.onResult(new ArrayList<>(), e);
        }
    }

    private static void add(List<Item> out, Rect r, String s) {
        if (r == null || s == null) return;
        s = s.trim();
        if (!s.isEmpty()) out.add(new Item(r, s));
    }

    /** Chat screenshot-er lekha: dan dike = sadharonoto user nije, bam dike = onnora. */
    public static String chatText(List<Item> items, int width) {
        StringBuilder sb = new StringBuilder();
        for (Item it : items) {
            int cx = it.box.centerX();
            String side = cx > width * 0.6f ? "[right] " : (cx < width * 0.4f ? "[left] " : "");
            sb.append(side).append(it.text).append('\n');
        }
        return sb.toString().trim();
    }

    /**
     * Shob item translate kore item.translated-e rakhe. Background thread-e call korun.
     * @return kon provider use holo
     */
    public static String translate(Context c, List<Item> items, String targetName) throws Exception {
        String provider = "";
        final int chunk = 50;
        for (int start = 0; start < items.size(); start += chunk) {
            List<Item> part = items.subList(start, Math.min(items.size(), start + chunk));
            JSONArray src = new JSONArray();
            for (Item it : part) src.put(it.text);
            String system = "You translate text that was read by OCR from a photo or screen. "
                    + "Translate each item of the given JSON array into " + targetName + ". "
                    + "Fix obvious OCR mistakes, keep numbers, prices, units and names. "
                    + "If an item is already in " + targetName + " or is only numbers/symbols, keep it as it is. "
                    + "Return ONLY a JSON object {\"t\": [...]} with exactly " + part.size()
                    + " strings, in the same order.";
            String[] r = AiClient.ask(c, system, src.toString(), true);
            provider = r[1];
            JSONObject j = AiClient.parseJson(r[0]);
            JSONArray t = j != null ? j.optJSONArray("t") : null;
            for (int i = 0; i < part.size(); i++) {
                String tr = (t != null && i < t.length()) ? t.optString(i, "") : "";
                part.get(i).translated = tr;
            }
        }
        return provider;
    }
}
