package com.maruf.aibubble;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Chhobi dekhay, ar proti lekhar thik upore translation boshay (Google Lens-er moto). */
public class LensView extends View {

    public interface OnItemTap {
        void onTap(Ocr.Item item);
    }

    private Bitmap bitmap;
    private List<Ocr.Item> items = new ArrayList<>();
    private boolean showOriginal = false;
    private OnItemTap tapListener;

    private final Paint bmPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Map<Ocr.Item, StaticLayout> layouts = new HashMap<>();
    private final Map<Ocr.Item, RectF> rects = new HashMap<>();
    private float scale = 1f, offX = 0f, offY = 0f;
    private float downX, downY;

    public LensView(Context c) {
        super(c);
        boxPaint.setColor(0xF2FFFFFF);
        hintPaint.setColor(0x552563EB);
        hintPaint.setStyle(Paint.Style.STROKE);
        hintPaint.setStrokeWidth(dp(1.5f));
        textPaint.setColor(0xFF111827);
    }

    public void setBitmap(Bitmap bm) {
        bitmap = bm;
        items = new ArrayList<>();
        layouts.clear();
        rects.clear();
        invalidate();
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setItems(List<Ocr.Item> list) {
        items = list == null ? new ArrayList<>() : list;
        layouts.clear();
        rects.clear();
        invalidate();
    }

    /** Translation ashle notun kore anka. */
    public void refresh() {
        layouts.clear();
        rects.clear();
        invalidate();
    }

    public void setShowOriginal(boolean v) {
        showOriginal = v;
        invalidate();
    }

    public boolean isShowingOriginal() {
        return showOriginal;
    }

    public void setOnItemTap(OnItemTap l) {
        tapListener = l;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layouts.clear();
        rects.clear();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.BLACK);
        if (bitmap == null) return;
        int w = getWidth(), h = getHeight();
        scale = Math.min((float) w / bitmap.getWidth(), (float) h / bitmap.getHeight());
        offX = (w - bitmap.getWidth() * scale) / 2f;
        offY = (h - bitmap.getHeight() * scale) / 2f;
        RectF dst = new RectF(offX, offY, offX + bitmap.getWidth() * scale, offY + bitmap.getHeight() * scale);
        canvas.drawBitmap(bitmap, null, dst, bmPaint);

        for (Ocr.Item it : items) {
            RectF r = mapped(it);
            String tr = it.translated;
            if (showOriginal || tr == null || tr.isEmpty()) {
                canvas.drawRoundRect(r, dp(4), dp(4), hintPaint);
                continue;
            }
            StaticLayout sl = layoutFor(it, r);
            RectF bg = new RectF(r.left - dp(2), r.top - dp(2),
                    r.left + Math.max(r.width(), sl.getWidth()) + dp(2),
                    r.top + Math.max(r.height(), sl.getHeight()) + dp(2));
            canvas.drawRoundRect(bg, dp(4), dp(4), boxPaint);
            canvas.save();
            float ty = r.top + Math.max(0, (r.height() - sl.getHeight()) / 2f);
            canvas.translate(r.left, ty);
            sl.draw(canvas);
            canvas.restore();
        }
    }

    private RectF mapped(Ocr.Item it) {
        RectF r = rects.get(it);
        if (r == null) {
            r = new RectF(offX + it.box.left * scale, offY + it.box.top * scale,
                    offX + it.box.right * scale, offY + it.box.bottom * scale);
            rects.put(it, r);
        }
        return r;
    }

    /** Box-er moddhe dhore emon boro font khoje ber kore. */
    private StaticLayout layoutFor(Ocr.Item it, RectF r) {
        StaticLayout sl = layouts.get(it);
        if (sl != null) return sl;
        String text = it.translated;
        int width = Math.max((int) r.width(), (int) dp(40));
        float max = Math.min(sp(18), Math.max(sp(9), r.height() * 0.8f));
        float size = max;
        while (true) {
            textPaint.setTextSize(size);
            sl = StaticLayout.Builder.obtain(text, 0, text.length(), textPaint, width)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setIncludePad(false)
                    .setLineSpacing(0, 1f)
                    .build();
            if (sl.getHeight() <= r.height() + dp(2) || size <= sp(8)) break;
            size -= 1f;
        }
        layouts.put(it, sl);
        return sl;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_UP) {
            if (Math.abs(e.getX() - downX) < dp(10) && Math.abs(e.getY() - downY) < dp(10)) {
                for (Ocr.Item it : items) {
                    RectF r = mapped(it);
                    RectF hit = new RectF(r.left - dp(6), r.top - dp(6), r.right + dp(6), r.bottom + dp(6));
                    if (hit.contains(e.getX(), e.getY())) {
                        if (tapListener != null) tapListener.onTap(it);
                        performClick();
                        return true;
                    }
                }
            }
            return true;
        }
        return super.onTouchEvent(e);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private float sp(float v) {
        return v * getResources().getDisplayMetrics().scaledDensity;
    }
}
