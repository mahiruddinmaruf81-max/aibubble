package com.maruf.aibubble;

import android.app.Notification;
import android.app.Person;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Chat app-er notification theke notun message pore bubble-e popup pathay.
 * Notification-er "Reply" button thakle shekhan diye sorasori reply pathano jay.
 */
public class MsgListenerService extends NotificationListenerService {

    private static final Set<String> APPS = new HashSet<>(Arrays.asList(
            "com.whatsapp", "com.whatsapp.w4b",
            "com.facebook.orca", "com.facebook.mlite", "com.facebook.katana",
            "com.tencent.mm", "com.tencent.mobileqq",
            "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
            "com.instagram.android", "com.imo.android.imoim", "com.imo.android.imoimbeta",
            "com.viber.voip", "jp.naver.line.android", "org.thoughtcrime.securesms",
            "com.google.android.apps.messaging", "com.samsung.android.messaging",
            "com.android.mms", "com.android.messaging", "com.skype.raider",
            "com.discord", "com.snapchat.android", "com.zhiliaoapp.musically"
    ));

    private static final Map<String, Notification.Action> replyActions = new ConcurrentHashMap<>();
    private static final Map<String, String> lastText = new ConcurrentHashMap<>();
    private static final Map<String, Long> lastAutoSend = new ConcurrentHashMap<>();

    private static volatile MsgListenerService instance;

    public static boolean isConnected() {
        return instance != null;
    }

    @Override
    public void onListenerConnected() {
        instance = this;
    }

    @Override
    public void onListenerDisconnected() {
        instance = null;
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Exception ignored) { }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Chat khule porle notification chole jay; reply action ar kaj kore na
        replyActions.remove(sbn.getKey());
    }

    private void handle(StatusBarNotification sbn) {
        if (!Prefs.get(this).getBoolean(Prefs.AUTO_POPUP, true)) return;
        String pkg = sbn.getPackageName();
        if (!APPS.contains(pkg)) return;
        Notification n = sbn.getNotification();
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if (sbn.isOngoing()) return;
        Bundle ex = n.extras;
        if (ex == null) return;

        CharSequence conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
        String sender = str(conv != null ? conv : ex.getCharSequence(Notification.EXTRA_TITLE));
        String text = null;

        // MessagingStyle: proti message ekta Bundle ("text", "sender", "sender_person")
        Parcelable[] arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (arr != null && arr.length > 0 && arr[arr.length - 1] instanceof Bundle) {
            Bundle last = (Bundle) arr[arr.length - 1];
            CharSequence who = last.getCharSequence("sender");
            Object person = last.get("sender_person");
            if (who == null && person != null && Build.VERSION.SDK_INT >= 28 && person instanceof Person) {
                who = ((Person) person).getName();
            }
            if (who == null && person == null) return; // nijer pathano message
            text = str(last.getCharSequence("text"));
            if (who != null) sender = conv != null ? sender + " · " + who : who.toString();
        }
        if (text == null || text.isEmpty()) {
            CharSequence big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
            text = str(big != null ? big : ex.getCharSequence(Notification.EXTRA_TEXT));
        }
        if (text == null || text.isEmpty()) return;
        if (text.matches("(?i)^\\d+\\s+(new\\s+)?messages?.*") || text.matches("^\\d+条.*")) return;

        String key = sbn.getKey();
        if (text.equals(lastText.get(key))) return;
        lastText.put(key, text);

        Notification.Action reply = findReplyAction(n);
        if (reply != null) replyActions.put(key, reply);
        else replyActions.remove(key);

        FloatingService fs = FloatingService.instance;
        if (fs != null) {
            fs.onIncoming(key, appName(pkg), pkg, sender == null ? "" : sender, text, reply != null);
        }
    }

    private static Notification.Action findReplyAction(Notification n) {
        if (n.actions != null) {
            for (Notification.Action a : n.actions) {
                if (isReply(a)) return a;
            }
        }
        // Kichu app (jemon WhatsApp) wearable-er moddhe reply rakhe
        Notification.WearableExtender we = new Notification.WearableExtender(n);
        for (Notification.Action a : we.getActions()) {
            if (isReply(a)) return a;
        }
        return null;
    }

    private static boolean isReply(Notification.Action a) {
        RemoteInput[] ri = a.getRemoteInputs();
        if (ri == null || ri.length == 0) return false;
        for (RemoteInput r : ri) if (r.getAllowFreeFormInput()) return true;
        return false;
    }

    public static boolean canReply(String key) {
        return key != null && replyActions.containsKey(key);
    }

    /** Notification-er Reply diye sorasori pathay. Shofol hole true. */
    public static boolean sendReply(Context c, String key, String text) {
        if (key == null) return false;
        Notification.Action a = replyActions.get(key);
        if (a == null) return false;
        try {
            RemoteInput[] ris = a.getRemoteInputs();
            Intent fill = new Intent();
            Bundle results = new Bundle();
            for (RemoteInput r : ris) results.putCharSequence(r.getResultKey(), text);
            RemoteInput.addResultsToIntent(ris, fill, results);
            a.actionIntent.send(c, 0, fill);
            replyActions.remove(key);
            return true;
        } catch (PendingIntent.CanceledException e) {
            replyActions.remove(key);
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /** Ek conversation-e beshi ghono ghono auto reply na (loop atkate). */
    public static boolean autoSendAllowed(String key) {
        long now = System.currentTimeMillis();
        Long last = lastAutoSend.get(key);
        if (last != null && now - last < 20000) return false;
        lastAutoSend.put(key, now);
        return true;
    }

    private String appName(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return String.valueOf(pm.getApplicationLabel(ai));
        } catch (Exception e) {
            return pkg;
        }
    }

    private static String str(CharSequence cs) {
        return cs == null ? null : cs.toString().trim();
    }
}
