package com.maruf.aibubble;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Settings: API key, model, provider select, bubble chalu/bondho. */
public class MainActivity extends Activity {

    private EditText dsKey, dsModel, gmKey, gmModel;
    private RadioButton rbDs, rbGm;
    private TextView permStatus, testResult, a11yStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("AI Bubble");

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(32));
        scroll.addView(box);
        setContentView(scroll);

        TextView intro = text("Screen-er upore bhasha bubble theke Bangla / English / 中文 translate ar "
                + "auto reply korun. Niche API key boshan, tarpor \"Bubble chalu korun\" chapun.", 14, 0xFF334155);
        box.addView(intro);

        // Provider
        box.addView(header("Kon AI use korben?"));
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        rbDs = new RadioButton(this);
        rbDs.setText("DeepSeek");
        rbDs.setId(1001);
        rbGm = new RadioButton(this);
        rbGm.setText("Gemini");
        rbGm.setId(1002);
        rg.addView(rbDs);
        rg.addView(rbGm);
        box.addView(rg);
        box.addView(text("Ekta fail korle onnota-r key thakle automatically sheta use hobe.", 12, 0xFF64748B));

        // DeepSeek
        box.addView(header("DeepSeek API"));
        dsKey = field("DeepSeek API key (sk-…)", true);
        box.addView(dsKey);
        dsModel = field("Model (default: " + Prefs.DEFAULT_DS_MODEL + ")", false);
        box.addView(dsModel);
        box.addView(text("Key paben: platform.deepseek.com → API keys", 12, 0xFF64748B));

        // Gemini
        box.addView(header("Gemini API"));
        gmKey = field("Gemini API key (AIza…)", true);
        box.addView(gmKey);
        gmModel = field("Model (default: " + Prefs.DEFAULT_GM_MODEL + ")", false);
        box.addView(gmModel);
        box.addView(text("Key paben: aistudio.google.com → Get API key", 12, 0xFF64748B));

        CheckBox show = new CheckBox(this);
        show.setText("Key dekhao");
        show.setOnCheckedChangeListener((b, on) -> {
            int t = InputType.TYPE_CLASS_TEXT | (on ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    : InputType.TYPE_TEXT_VARIATION_PASSWORD);
            dsKey.setInputType(t);
            gmKey.setInputType(t);
        });
        box.addView(show);

        Button save = button("💾 Save korun", 0xFF0F172A);
        save.setOnClickListener(v -> { save(); toast("Save hoyeche"); });
        box.addView(save, top(dp(10)));

        Button test = button("🧪 API test korun", 0xFF64748B);
        test.setOnClickListener(v -> runTest());
        box.addView(test, top(dp(8)));
        testResult = text("", 13, 0xFF334155);
        box.addView(testResult, top(dp(6)));

        // Bubble
        box.addView(header("Floating bubble"));
        permStatus = text("", 13, 0xFF334155);
        box.addView(permStatus);
        Button start = button("▶ Bubble chalu korun", 0xFF2563EB);
        start.setOnClickListener(v -> startBubble());
        box.addView(start, top(dp(8)));
        Button stop = button("■ Bubble bondho korun", 0xFFDC2626);
        stop.setOnClickListener(v -> {
            if (FloatingService.running) {
                startService(new Intent(this, FloatingService.class).setAction(FloatingService.ACTION_STOP));
            }
            toast("Bubble bondho");
        });
        box.addView(stop, top(dp(8)));

        // Screen pora (jekono chat app)
        box.addView(header("Screen theke auto reply"));
        box.addView(text("Messenger, WhatsApp, WeChat, Telegram, Instagram, IMO — jekono app-er chat khola "
                + "obosthay bubble chaplei app nije message pore Bangla mane ar reply dekhabe.", 13, 0xFF334155));
        a11yStatus = text("", 13, 0xFF334155);
        box.addView(a11yStatus, top(dp(6)));
        Button a11y = button("📱 Screen pora chalu korun", 0xFF16A34A);
        a11y.setOnClickListener(v -> {
            toast("\"AI Bubble (chat porar jonno)\" on korun");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
        box.addView(a11y, top(dp(8)));
        Button restricted = button("🔓 \"Restricted setting\" allow korun", 0xFF64748B);
        restricted.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        box.addView(restricted, top(dp(8)));
        box.addView(text("Accessibility-te AI Bubble dhushor (on kora jay na) thakle: upore button chapun → "
                + "upore dan kone ⋮ → \"Allow restricted settings\" → tarpor abar Accessibility on korun.",
                12, 0xFF64748B));
        CheckBox autoRead = new CheckBox(this);
        autoRead.setText("Bubble chaplei screen pore reply dekhao");
        autoRead.setChecked(Prefs.get(this).getBoolean(Prefs.AUTO_READ, true));
        autoRead.setOnCheckedChangeListener((b, on) ->
                Prefs.get(this).edit().putBoolean(Prefs.AUTO_READ, on).apply());
        box.addView(autoRead, top(dp(6)));

        box.addView(header("Kivabe use korben"));
        box.addView(text(
                "1. Panel-e reply-r bhasha select korun (বাংলা / English / 中文). Eta mone thakbe.\n"
                + "2. Jekono chat app khulun, bubble (文A) chapun → app nije chat pore \"Ora bolche\" (Bangla mane) ar reply dekhabe.\n"
                + "3. Reply pochondo hole ➤ Send → app beche nin. Text copy-o thake, chat box-e paste-o korte paren.\n"
                + "4. Screen pora off thakle: message Copy → bubble → 📋 Paste → Translate ba Auto Reply.\n"
                + "5. Panel khola obosthay 📱 Screen chaple abar notun kore pore.\n"
                + "6. Bubble tene jekono jaygay rakhte parben. Bondho korte panel-er niche \"Bubble bondho\" ba notification use korun.",
                14, 0xFF334155));

        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean ok = Settings.canDrawOverlays(this);
        permStatus.setText(ok ? "✓ \"Display over other apps\" permission ache"
                : "✗ \"Display over other apps\" permission lagbe (Bubble chalu korle setting khulbe)");
        permStatus.setTextColor(ok ? 0xFF16A34A : 0xFFDC2626);
        boolean a = ScreenReaderService.isOn();
        a11yStatus.setText(a ? "✓ Screen pora chalu ache" : "✗ Screen pora bondho (niche button chapun)");
        a11yStatus.setTextColor(a ? 0xFF16A34A : 0xFFDC2626);
    }

    private void load() {
        SharedPreferences p = Prefs.get(this);
        dsKey.setText(p.getString(Prefs.DS_KEY, ""));
        dsModel.setText(p.getString(Prefs.DS_MODEL, ""));
        gmKey.setText(p.getString(Prefs.GM_KEY, ""));
        gmModel.setText(p.getString(Prefs.GM_MODEL, ""));
        if ("gemini".equals(Prefs.provider(this))) rbGm.setChecked(true); else rbDs.setChecked(true);
    }

    private void save() {
        Prefs.get(this).edit()
                .putString(Prefs.DS_KEY, dsKey.getText().toString().trim())
                .putString(Prefs.DS_MODEL, dsModel.getText().toString().trim())
                .putString(Prefs.GM_KEY, gmKey.getText().toString().trim())
                .putString(Prefs.GM_MODEL, gmModel.getText().toString().trim())
                .putString(Prefs.PROVIDER, rbGm.isChecked() ? "gemini" : "deepseek")
                .apply();
    }

    private void runTest() {
        save();
        testResult.setTextColor(0xFF64748B);
        testResult.setText("⏳ Test hocche…");
        new Thread(() -> {
            String msg;
            int color;
            try {
                String[] r = AiClient.ask(getApplicationContext(),
                        "Translate the user's text into Bengali (Bangla script). Output only the translation.",
                        "Hello, how are you?");
                msg = "✓ Kaj korche (" + r[1] + "): " + r[0];
                color = 0xFF16A34A;
            } catch (Exception e) {
                msg = "❌ " + e.getMessage();
                color = 0xFFDC2626;
            }
            final String m = msg;
            final int c = color;
            runOnUiThread(() -> {
                testResult.setText(m);
                testResult.setTextColor(c);
            });
        }).start();
    }

    private void startBubble() {
        save();
        if (!Settings.canDrawOverlays(this)) {
            toast("\"AI Bubble\"-ke Allow korun, tarpor back ashe abar chapun");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
        startForegroundService(new Intent(this, FloatingService.class));
        toast("Bubble chalu hoyeche");
        moveTaskToBack(true);
    }

    // ---------- ui helpers ----------

    private TextView header(String s) {
        TextView t = text(s, 16, 0xFF0F172A);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(20), 0, dp(4));
        return t;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT
                | (secret ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));
        return e;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(12));
        b.setBackground(d);
        b.setStateListAnimator(null);
        return b;
    }

    private LinearLayout.LayoutParams top(int m) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = m;
        return lp;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
