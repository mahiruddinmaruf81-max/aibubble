package com.maruf.aibubble;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Setting: API key, bubble, screen pora, message popup, lens, voice. */
public class MainActivity extends Activity {

    private static final int BG = 0xFFF1F5F9, CARD = 0xFFFFFFFF, TEXT = 0xFF0F172A, SUB = 0xFF64748B;
    private static final int ACCENT = 0xFF2563EB, GREEN = 0xFF16A34A, RED = 0xFFDC2626, PURPLE = 0xFF7C3AED;

    private EditText dsKey, dsModel, gmKey, gmModel;
    private TextView testResult;
    private TextView stBubble, stScreen, stNotif;
    private final TextView[] provChips = new TextView[3];
    private String provider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(18), dp(16), dp(32));
        scroll.addView(box);
        setContentView(scroll);

        // ---- header
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = new TextView(this);
        logo.setText("文A");
        logo.setTextColor(Color.WHITE);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable lbg = new GradientDrawable();
        lbg.setShape(GradientDrawable.OVAL);
        lbg.setColor(ACCENT);
        logo.setBackground(lbg);
        head.addView(logo, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        TextView title = text("AI Bubble", 22, TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        ht.addView(title);
        ht.addView(text("Translate · Auto reply · Lens · Voice", 13, SUB));
        head.addView(ht);
        box.addView(head);

        // ---- quick tools
        LinearLayout quick = new LinearLayout(this);
        quick.setPadding(0, dp(14), 0, 0);
        TextView lensBtn = button("📷  Lens", PURPLE);
        lensBtn.setOnClickListener(v -> {
            Intent i = new Intent(this, LensActivity.class);
            i.putExtra(LensActivity.EXTRA_SOURCE, "camera");
            startActivity(i);
        });
        TextView voiceBtn = button("🎤  Voice", GREEN);
        voiceBtn.setOnClickListener(v -> startActivity(new Intent(this, ConversationActivity.class)));
        LinearLayout.LayoutParams q1 = new LinearLayout.LayoutParams(0, dp(50), 1f);
        q1.rightMargin = dp(6);
        LinearLayout.LayoutParams q2 = new LinearLayout.LayoutParams(0, dp(50), 1f);
        q2.leftMargin = dp(6);
        quick.addView(lensBtn, q1);
        quick.addView(voiceBtn, q2);
        box.addView(quick);
        TextView trainBtn = button("🧠  AI shekhan (apnar moto reply)", ACCENT);
        trainBtn.setOnClickListener(v -> startActivity(new Intent(this, TrainActivity.class)));
        box.addView(trainBtn, top(dp(10), dp(50)));

        // ---- 1. AI
        LinearLayout c1 = card(box, "1", "AI key");
        c1.addView(text("Duita key-i din. VPN off thakle Gemini kaj kore na, tokhon \"Auto\" nije DeepSeek use korbe.",
                13, SUB));
        LinearLayout provRow = new LinearLayout(this);
        provRow.setPadding(0, dp(10), 0, dp(4));
        String[] pv = {"auto", "deepseek", "gemini"};
        String[] pl = {"⚡ Auto", "DeepSeek", "Gemini"};
        for (int i = 0; i < 3; i++) {
            final String code = pv[i];
            TextView chip = chip(pl[i]);
            chip.setOnClickListener(v -> {
                provider = code;
                refreshProv();
            });
            provChips[i] = chip;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            provRow.addView(chip, lp);
        }
        c1.addView(provRow);

        c1.addView(label("DeepSeek (VPN chara cholbe)"));
        dsKey = field("DeepSeek API key (sk-…)", true);
        c1.addView(dsKey);
        dsModel = field("Model (default: " + Prefs.DEFAULT_DS_MODEL + ")", false);
        c1.addView(dsModel);
        c1.addView(text("Key: platform.deepseek.com → API keys", 12, SUB));

        c1.addView(label("Gemini (VPN lage)"));
        gmKey = field("Gemini API key (AIza…)", true);
        c1.addView(gmKey);
        gmModel = field("Model (default: " + Prefs.DEFAULT_GM_MODEL + ")", false);
        c1.addView(gmModel);
        c1.addView(text("Key: aistudio.google.com → Get API key", 12, SUB));

        CheckBox show = new CheckBox(this);
        show.setText("Key dekhao");
        show.setTextColor(TEXT);
        show.setOnCheckedChangeListener((b, on) -> {
            int t = InputType.TYPE_CLASS_TEXT | (on ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    : InputType.TYPE_TEXT_VARIATION_PASSWORD);
            dsKey.setInputType(t);
            gmKey.setInputType(t);
        });
        c1.addView(show);

        LinearLayout saveRow = new LinearLayout(this);
        TextView save = button("💾  Save", TEXT);
        save.setOnClickListener(v -> {
            save();
            toast("Save hoyeche");
        });
        TextView test = button("🧪  Test", SUB);
        test.setOnClickListener(v -> runTest());
        LinearLayout.LayoutParams s1 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        s1.rightMargin = dp(5);
        LinearLayout.LayoutParams s2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        s2.leftMargin = dp(5);
        saveRow.addView(save, s1);
        saveRow.addView(test, s2);
        c1.addView(saveRow, top(dp(6)));
        testResult = text("", 13, SUB);
        c1.addView(testResult, top(dp(6)));

        // ---- 2. Bubble
        LinearLayout c2 = card(box, "2", "Floating bubble");
        stBubble = text("", 13, SUB);
        c2.addView(stBubble);
        LinearLayout bRow = new LinearLayout(this);
        TextView start = button("▶  Chalu", ACCENT);
        start.setOnClickListener(v -> startBubble());
        TextView stop = button("■  Bondho", RED);
        stop.setOnClickListener(v -> {
            if (FloatingService.running) {
                startService(new Intent(this, FloatingService.class).setAction(FloatingService.ACTION_STOP));
            }
            toast("Bubble bondho");
            stBubble.postDelayed(this::refreshStatus, 400);
        });
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        b1.rightMargin = dp(5);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        b2.leftMargin = dp(5);
        bRow.addView(start, b1);
        bRow.addView(stop, b2);
        c2.addView(bRow, top(dp(8)));
        c2.addView(text("Double tap: bubble kinare lukabe / beriye ashbe. Ek tap: panel khulbe.", 12, SUB), top(dp(8)));
        LinearLayout picRow = new LinearLayout(this);
        TextView pic = button("🖼  Bubble-er chhobi", PURPLE);
        pic.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            try { startActivityForResult(i, REQ_BUBBLE_PIC); } catch (Exception e) { toast("Gallery khola gelo na"); }
        });
        TextView reset = button("↺  文A", SUB);
        reset.setOnClickListener(v -> {
            new java.io.File(getFilesDir(), "bubble.png").delete();
            FloatingService fs = FloatingService.instance;
            if (fs != null) fs.applyBubbleLook();
            toast("Ager bubble ferot");
        });
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dp(46), 2f);
        p1.rightMargin = dp(5);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        p2.leftMargin = dp(5);
        picRow.addView(pic, p1);
        picRow.addView(reset, p2);
        c2.addView(picRow, top(dp(8)));

        // ---- 3. Screen pora
        LinearLayout c3 = card(box, "3", "Screen pora");
        c3.addView(text("Jekono chat app khola obosthay bubble chaplei message pore Bangla mane ar reply dekhabe. "
                + "🔍 diye screen-er upore translate-o hobe.", 13, SUB));
        stScreen = text("", 13, SUB);
        c3.addView(stScreen, top(dp(6)));
        TextView a11y = button("📱  Accessibility khulun", GREEN);
        a11y.setOnClickListener(v -> {
            toast("\"AI Bubble (chat porar jonno)\" on korun");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
        c3.addView(a11y, top(dp(8), dp(46)));
        CheckBox autoRead = check("Bubble chaplei screen pore reply dekhao", Prefs.AUTO_READ, true);
        c3.addView(autoRead);

        // ---- 4. Message popup
        LinearLayout c4 = card(box, "4", "Message ashle auto popup");
        c4.addView(text("WhatsApp, Messenger, WeChat, Telegram, IMO, SMS ityadi-te notun message ashle "
                + "upore popup-e mane ar reply dekhabe. Send chaple sorasori pathabe.", 13, SUB));
        stNotif = text("", 13, SUB);
        c4.addView(stNotif, top(dp(6)));
        TextView notif = button("🔔  Notification access khulun", ACCENT);
        notif.setOnClickListener(v -> {
            toast("\"AI Bubble\" on korun");
            try {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        c4.addView(notif, top(dp(8), dp(46)));
        c4.addView(check("Message ashle popup dekhao", Prefs.AUTO_POPUP, true));
        CheckBox autoSend = check("Nije nije reply pathiye dao (shabdhane!)", Prefs.AUTO_SEND, false);
        autoSend.setOnCheckedChangeListener((b, on) -> {
            Prefs.get(this).edit().putBoolean(Prefs.AUTO_SEND, on).apply();
            if (on) toast("Ekhon theke AI-er reply nije nije chole jabe");
        });
        c4.addView(autoSend);

        // ---- 5. Setting kaj na korle
        LinearLayout c5 = card(box, "5", "Kaj na korle (Xiaomi / onno phone)");
        c5.addView(text("• Accessibility ba Notification-e AI Bubble dhushor (on hoy na) thakle: niche button → "
                + "upore ⋮ → \"Allow restricted settings\" → abar on korun.\n"
                + "• Bubble/screen pora nije bondho hoye gele: Battery → \"No restrictions\", ar Autostart on korun.\n"
                + "• Recent apps-e AI Bubble lock kore rakhun.", 13, SUB));
        TextView appInfo = button("⚙️  App info / Battery / Restricted", SUB);
        appInfo.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        c5.addView(appInfo, top(dp(8), dp(46)));

        // ---- 6. Use
        LinearLayout c6 = card(box, "6", "Kivabe use korben");
        c6.addView(text(
                "📱 Chat khule bubble chapun → \"Ora bolche\" + reply → Send\n"
                + "🔍 Screen-er Chinese lekhar upore Bangla/English boshe jabe\n"
                + "📷 Chhobi tulun → chhobi-r lekhar upore translation\n"
                + "🎤 Duita bhasha select kore bolun → live translate + shonabe\n"
                + "✏️ Nije likhe / paste kore translate ba reply\n"
                + "Panel-e Auto / বাং / EN / 中 = reply-r bhasha. Auto = je bhashay message, shei bhashay.",
                14, TEXT));

        load();
    }

    private static final int REQ_BUBBLE_PIC = 31;

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_BUBBLE_PIC || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(() -> {
            try {
                android.graphics.Bitmap src = Media.loadUri(this, uri, 600);
                android.graphics.Bitmap round = Media.circle(src, dp(56) * 2, dp(2) * 2);
                try (java.io.FileOutputStream fos = new java.io.FileOutputStream(new java.io.File(getFilesDir(), "bubble.png"))) {
                    round.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fos);
                }
                runOnUiThread(() -> {
                    FloatingService fs = FloatingService.instance;
                    if (fs != null) fs.applyBubbleLook();
                    toast("Bubble-er chhobi bodle geche");
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("Chhobi neya gelo na: " + e.getMessage()));
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        boolean overlay = Settings.canDrawOverlays(this);
        if (FloatingService.running) setStatus(stBubble, true, "Bubble chalu ache");
        else if (!overlay) setStatus(stBubble, false, "\"Display over other apps\" permission lagbe (Chalu chaple khulbe)");
        else setStatus(stBubble, false, "Bubble bondho");

        if (ScreenReaderService.isOn()) setStatus(stScreen, true, "Screen pora chalu ache");
        else if (Prefs.a11yEnabledInSettings(this))
            setStatus(stScreen, false, "Setting-e on, kintu cholche na. Off kore abar on korun.");
        else setStatus(stScreen, false, "Screen pora bondho");

        if (Prefs.notifAccessEnabled(this)) setStatus(stNotif, true, "Message popup chalu ache");
        else setStatus(stNotif, false, "Notification access bondho");
    }

    private void setStatus(TextView t, boolean ok, String s) {
        t.setText((ok ? "✓ " : "✗ ") + s);
        t.setTextColor(ok ? GREEN : RED);
    }

    private void load() {
        SharedPreferences p = Prefs.get(this);
        dsKey.setText(p.getString(Prefs.DS_KEY, ""));
        dsModel.setText(p.getString(Prefs.DS_MODEL, ""));
        gmKey.setText(p.getString(Prefs.GM_KEY, ""));
        String gm = p.getString(Prefs.GM_MODEL, "");
        if ("gemini-2.5-flash".equals(gm)) gm = ""; // purono naam, ar kaj kore na
        gmModel.setText(gm);
        provider = Prefs.provider(this);
        refreshProv();
    }

    private void refreshProv() {
        String[] pv = {"auto", "deepseek", "gemini"};
        for (int i = 0; i < 3; i++) {
            boolean on = pv[i].equals(provider);
            provChips[i].setBackground(round(on ? TEXT : BG, dp(12)));
            provChips[i].setTextColor(on ? Color.WHITE : TEXT);
        }
    }

    private void save() {
        Prefs.get(this).edit()
                .putString(Prefs.DS_KEY, dsKey.getText().toString().trim())
                .putString(Prefs.DS_MODEL, dsModel.getText().toString().trim())
                .putString(Prefs.GM_KEY, gmKey.getText().toString().trim())
                .putString(Prefs.GM_MODEL, gmModel.getText().toString().trim())
                .putString(Prefs.PROVIDER, provider)
                .apply();
    }

    private void runTest() {
        save();
        testResult.setTextColor(SUB);
        testResult.setText("⏳ Test hocche…");
        new Thread(() -> {
            String msg;
            int color;
            try {
                String[] r = AiClient.ask(getApplicationContext(),
                        "Translate the user's text into Bengali (Bangla script). Output only the translation.",
                        "Hello, how are you?");
                msg = "✓ Kaj korche (" + r[1] + "): " + r[0];
                color = GREEN;
            } catch (Exception e) {
                msg = "❌ " + e.getMessage();
                color = RED;
            }
            final String m = msg;
            final int c = color;
            runOnUiThread(() -> {
                testResult.setText(m);
                testResult.setTextColor(c);
            });
        }).start();
    }

    private void startBubble() {
        save();
        if (!Settings.canDrawOverlays(this)) {
            toast("\"AI Bubble\"-ke Allow korun, tarpor back ashe abar chapun");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
        startForegroundService(new Intent(this, FloatingService.class));
        toast("Bubble chalu hoyeche");
        stBubble.postDelayed(this::refreshStatus, 400);
    }

    // ---------- ui helpers ----------

    private LinearLayout card(LinearLayout parent, String num, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(round(CARD, dp(18)));
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(0, 0, 0, dp(6));
        TextView n = new TextView(this);
        n.setText(num);
        n.setTextColor(ACCENT);
        n.setTypeface(Typeface.DEFAULT_BOLD);
        n.setGravity(Gravity.CENTER);
        n.setBackground(round(0xFFDBEAFE, dp(13)));
        h.addView(n, new LinearLayout.LayoutParams(dp(26), dp(26)));
        TextView t = text("  " + title, 16, TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        h.addView(t);
        c.addView(h);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        parent.addView(c, lp);
        return c;
    }

    private CheckBox check(String s, String key, boolean def) {
        CheckBox cb = new CheckBox(this);
        cb.setText(s);
        cb.setTextColor(TEXT);
        cb.setChecked(Prefs.get(this).getBoolean(key, def));
        cb.setOnCheckedChangeListener((b, on) -> Prefs.get(this).edit().putBoolean(key, on).apply());
        return cb;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(12), 0, 0);
        return t;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.2f);
        return t;
    }

    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        e.setInputType(InputType.TYPE_CLASS_TEXT
                | (secret ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));
        return e;
    }

    private TextView chip(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return t;
    }

    private TextView button(String s, int color) {
        TextView b = new TextView(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, dp(14)));
        return b;
    }

    private GradientDrawable round(int color, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(r);
        return d;
    }

    private LinearLayout.LayoutParams top(int m) {
        return top(m, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams top(int m, int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h);
        lp.topMargin = m;
        return lp;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
