package com.maruf.aibubble;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Screen-er upore shob shomoy bhashte thaka bubble.
 * Bubble-e tap korle Translate / Auto Reply panel khule.
 */
public class FloatingService extends Service {

    public static final String ACTION_STOP = "com.maruf.aibubble.STOP";
    public static final String ACTION_OPEN = "com.maruf.aibubble.OPEN";
    public static final String EXTRA_TEXT = "text";

    public static volatile boolean running = false;

    private static final String[] LANG_CODES = {"bn", "en", "zh"};
    private static final String[] LANG_LABELS = {"বাংলা", "English", "中文"};
    private static final String[] LANG_NAMES = {
            "Bengali (Bangla script)", "English", "Simplified Chinese"};

    private static final int BLUE = 0xFF2563EB;
    private static final int GREEN = 0xFF16A34A;
    private static final int GREY = 0xFF64748B;
    private static final int DARK = 0xFF0F172A;

    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private TextView bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleLp, panelLp;
    private boolean bubbleShown = false, panelShown = false;

    private EditText input, output;
    private TextView status, providerChip, meaning;
    private boolean inputFromScreen = false;
    private final Button[] langButtons = new Button[3];
    private Button translateBtn, replyBtn;
    private String lang;
    private boolean busy = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        lang = Prefs.get(this).getString(Prefs.LANG, "bn");
        startAsForeground();
        try {
            createBubble();
            createPanel();
            showBubble();
        } catch (Exception e) {
            Toast.makeText(this, "Bubble dekhano gelo na. \"Display over other apps\" permission din.",
                    Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP.equals(action)) {
                stopSelf();
                return START_NOT_STICKY;
            }
            if (ACTION_OPEN.equals(action) && panel != null) {
                String t = intent.getStringExtra(EXTRA_TEXT);
                if (t != null) {
                    input.setText(t);
                    inputFromScreen = false;
                    output.setText("");
                    status.setText("");
                    setMeaning(null);
                }
                showPanel();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (bubbleShown) wm.removeView(bubble); } catch (Exception ignored) { }
        try { if (panelShown) wm.removeView(panel); } catch (Exception ignored) { }
        bubbleShown = panelShown = false;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ notification

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel("bubble", "AI Bubble",
                NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);

        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, FloatingService.class).setAction(ACTION_STOP), flags);
        PendingIntent open = PendingIntent.getActivity(this, 2,
                new Intent(this, MainActivity.class), flags);

        Notification n = new Notification.Builder(this, "bubble")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("AI Bubble chalu ache")
                .setContentText("Bubble-e tap kore Translate / Auto Reply korun")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat), "Bondho korun", stop).build())
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ------------------------------------------------------------------ bubble

    private void createBubble() {
        final int size = dp(56);
        bubble = new TextView(this);
        bubble.setText("文A");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(BLUE);
        bg.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(bg);
        bubble.setElevation(dp(6));

        bubbleLp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = screenWidth() - size - dp(4);
        bubbleLp.y = dp(220);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bubbleLp.x = startX + (int) dx;
                            bubbleLp.y = Math.max(0, startY + (int) dy);
                            safeUpdate(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) snapToEdge(size);
                        else onBubbleTap();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void snapToEdge(int size) {
        int w = screenWidth();
        bubbleLp.x = (bubbleLp.x + size / 2 < w / 2) ? 0 : w - size;
        safeUpdate(bubble, bubbleLp);
    }

    private void showBubble() {
        if (!bubbleShown) {
            wm.addView(bubble, bubbleLp);
            bubbleShown = true;
        }
    }

    private void hideBubble() {
        if (bubbleShown) {
            try { wm.removeView(bubble); } catch (Exception ignored) { }
            bubbleShown = false;
        }
    }

    // ------------------------------------------------------------------ panel

    private void createPanel() {
        FrameLayout root = new FrameLayout(this) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent ev) {
                if (ev.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                    if (ev.getAction() == KeyEvent.ACTION_UP) hidePanel();
                    return true;
                }
                return super.dispatchKeyEvent(ev);
            }
        };

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0xFFE2E8F0);
        scroll.setBackground(bg);
        scroll.setElevation(dp(10));
        scroll.addView(box);
        root.addView(scroll);

        // Header: title + provider chip + close
        LinearLayout header = row();
        TextView title = new TextView(this);
        title.setText("AI Translate & Reply");
        title.setTextColor(DARK);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        providerChip = new TextView(this);
        providerChip.setTextColor(BLUE);
        providerChip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        providerChip.setPadding(dp(10), dp(4), dp(10), dp(4));
        providerChip.setBackground(rounded(0xFFDBEAFE, dp(12)));
        providerChip.setOnClickListener(v -> toggleProvider());
        header.addView(providerChip);
        refreshProviderChip();

        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        close.setTextColor(GREY);
        close.setPadding(dp(14), 0, dp(4), 0);
        close.setOnClickListener(v -> hidePanel());
        header.addView(close);
        box.addView(header);

        // Input
        input = editBox("Message ekhane paste korun ba likhun…", 3, 6);
        box.addView(input, marginTop(dp(10)));

        LinearLayout inRow = row();
        inRow.addView(smallBtn("📱 Screen", v -> readScreenAndReply(true)), weighted());
        inRow.addView(smallBtn("📋 Paste", v -> pasteClipboard()), weighted());
        inRow.addView(smallBtn("🗑 Clear", v -> {
            input.setText("");
            inputFromScreen = false;
            output.setText("");
            status.setText("");
            setMeaning(null);
        }), weighted());
        box.addView(inRow, marginTop(dp(6)));

        // Language
        TextView langLabel = label("Kon bhashay?");
        box.addView(langLabel, marginTop(dp(10)));
        LinearLayout langRow = row();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Button b = baseBtn(LANG_LABELS[i]);
            b.setOnClickListener(v -> selectLang(LANG_CODES[idx]));
            langButtons[i] = b;
            langRow.addView(b, weighted());
        }
        box.addView(langRow, marginTop(dp(4)));
        refreshLangButtons();

        // Actions
        LinearLayout actRow = row();
        translateBtn = colorBtn("🌐 Translate", BLUE);
        translateBtn.setOnClickListener(v -> run(false));
        replyBtn = colorBtn("💬 Auto Reply", GREEN);
        replyBtn.setOnClickListener(v -> run(true));
        actRow.addView(translateBtn, weighted());
        actRow.addView(replyBtn, weighted());
        box.addView(actRow, marginTop(dp(10)));

        status = new TextView(this);
        status.setTextColor(GREY);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        box.addView(status, marginTop(dp(6)));

        // Ora ki bolche (Bangla mane)
        meaning = new TextView(this);
        meaning.setTextColor(0xFF78350F);
        meaning.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        meaning.setPadding(dp(10), dp(8), dp(10), dp(8));
        meaning.setBackground(rounded(0xFFFEF3C7, dp(10)));
        meaning.setVisibility(View.GONE);
        box.addView(meaning, marginTop(dp(4)));

        // Output
        output = editBox("Ekhane result asbe (dorkar hole edit korte parben)", 3, 8);
        box.addView(output, marginTop(dp(4)));

        LinearLayout outRow = row();
        Button copy = colorBtn("📄 Copy", GREY);
        copy.setOnClickListener(v -> {
            String s = output.getText().toString().trim();
            if (s.isEmpty()) { toast("Age Translate ba Auto Reply chapun"); return; }
            copyText(s);
            toast("Copy hoyeche");
        });
        Button send = colorBtn("➤ Send", 0xFF7C3AED);
        send.setOnClickListener(v -> sendResult());
        outRow.addView(copy, weighted());
        outRow.addView(send, weighted());
        box.addView(outRow, marginTop(dp(8)));

        TextView stopLink = new TextView(this);
        stopLink.setText("Bubble bondho korun");
        stopLink.setTextColor(0xFFDC2626);
        stopLink.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        stopLink.setGravity(Gravity.CENTER);
        stopLink.setPadding(0, dp(10), 0, dp(2));
        stopLink.setOnClickListener(v -> stopSelf());
        box.addView(stopLink);

        panel = root;
        panelLp = new WindowManager.LayoutParams(
                Math.min(screenWidth() - dp(20), dp(480)),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelLp.y = dp(40);
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN;
    }

    private void showPanel() {
        if (panelShown) return;
        hideBubble();
        panelLp.width = Math.min(screenWidth() - dp(20), dp(480));
        try {
            wm.addView(panel, panelLp);
            panelShown = true;
            refreshProviderChip();
        } catch (Exception e) {
            toast("Panel khola gelo na");
            showBubble();
        }
    }

    private void hidePanel() {
        if (!panelShown) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(panel.getWindowToken(), 0);
        try { wm.removeView(panel); } catch (Exception ignored) { }
        panelShown = false;
        try { showBubble(); } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ actions

    /** Bubble chaple: Accessibility on thakle jekono app-er screen pore sathe sathe reply. */
    private void onBubbleTap() {
        boolean auto = Prefs.get(this).getBoolean(Prefs.AUTO_READ, true);
        String chat = (auto && ScreenReaderService.isOn()) ? ScreenReaderService.readChat() : null;
        showPanel();
        if (!TextUtils.isEmpty(chat)) {
            fillFromScreen(chat);
            run(true);
        } else if (auto && !ScreenReaderService.isOn() && input.getText().length() == 0) {
            status.setTextColor(GREY);
            status.setText("Tip: AI Bubble app-e \"Screen pora chalu korun\" dile bubble chaplei reply dekhabe.");
        }
    }

    /** Panel khola obosthay "📱 Screen" button. */
    private void readScreenAndReply(boolean alsoReply) {
        if (!ScreenReaderService.isOn()) {
            toast("Age AI Bubble app theke Accessibility (screen pora) chalu korun");
            return;
        }
        String chat = ScreenReaderService.readChat();
        if (TextUtils.isEmpty(chat)) {
            toast("Screen-e kono lekha paoa gelo na");
            return;
        }
        fillFromScreen(chat);
        if (alsoReply) run(true);
    }

    private void fillFromScreen(String chat) {
        input.setText(chat);
        inputFromScreen = true;
        output.setText("");
        setMeaning(null);
    }

    private void setMeaning(String s) {
        if (meaning == null) return;
        if (TextUtils.isEmpty(s)) {
            meaning.setText("");
            meaning.setVisibility(View.GONE);
        } else {
            meaning.setText("🗨 Ora bolche: " + s);
            meaning.setVisibility(View.VISIBLE);
        }
    }

    private void run(final boolean reply) {
        final String text = input.getText().toString().trim();
        if (text.isEmpty()) { toast("Age message paste korun ba likhun"); return; }
        if (busy) return;
        busy = true;
        setButtonsEnabled(false);
        status.setTextColor(GREY);
        status.setText(reply ? "⏳ Reply banano hocche…" : "⏳ Translate hocche…");
        if (reply) setMeaning(null);

        final String langName = langName(lang);
        final boolean screen = inputFromScreen;
        final String screenNote = "The input is raw text read from the user's chat app screen, from top to bottom. "
                + "It may contain names, times, dates, buttons, menu items and other app labels: ignore those. "
                + "Messages near the bottom are the newest. ";
        final String system;
        if (reply) {
            system = "You help the user reply to chat messages. "
                    + (screen
                        ? screenNote + "Find the newest message(s) sent by the OTHER person (not the user) and reply to them, using the earlier messages as context. "
                        : "The input is a message the user RECEIVED from someone (it may be in any language). ")
                    + "Return ONLY a JSON object with exactly two keys: "
                    + "\"meaning\": a short Bengali (Bangla script) translation of what the other person said; "
                    + "\"reply\": ONE short, natural, polite and friendly reply written in " + langName
                    + " that the user can send back. No markdown, no code fences, no extra text.";
        } else {
            system = "You are a professional translator. "
                    + (screen ? screenNote + "Translate only the chat messages, one per line. " : "")
                    + "Detect the language and translate into " + langName
                    + ". Keep the meaning, tone, names, numbers and emojis. "
                    + "Output ONLY the translated text, with no explanations, labels or quotation marks.";
        }

        new Thread(() -> {
            String result = null, provider = null, error = null, mean = null;
            try {
                String[] r = AiClient.ask(getApplicationContext(), system, text);
                result = r[0];
                provider = r[1];
                if (reply) {
                    String[] parsed = parseReply(result);
                    mean = parsed[0];
                    result = parsed[1];
                }
            } catch (Exception e) {
                error = e.getMessage();
            }
            final String fResult = result, fProvider = provider, fError = error, fMean = mean;
            main.post(() -> {
                busy = false;
                setButtonsEnabled(true);
                if (fError != null) {
                    status.setTextColor(0xFFDC2626);
                    status.setText("❌ " + fError);
                } else {
                    if (reply) setMeaning(fMean);
                    output.setText(fResult);
                    status.setTextColor(GREEN);
                    status.setText("✓ " + (reply ? "Reply ready, pochondo hole ➤ Send" : "Translate hoyeche")
                            + " · " + fProvider);
                }
            });
        }).start();
    }

    /** AI-er JSON uttor theke [meaning, reply] ber kore. JSON na hole puro lekha-ke reply dhore. */
    private static String[] parseReply(String raw) {
        String s = raw.trim();
        int a = s.indexOf('{'), b = s.lastIndexOf('}');
        if (a >= 0 && b > a) {
            try {
                org.json.JSONObject j = new org.json.JSONObject(s.substring(a, b + 1));
                String rep = j.optString("reply", "").trim();
                if (!rep.isEmpty()) return new String[]{j.optString("meaning", "").trim(), rep};
            } catch (Exception ignored) { }
        }
        return new String[]{null, s};
    }

    private void sendResult() {
        String s = output.getText().toString().trim();
        if (s.isEmpty()) s = input.getText().toString().trim();
        if (s.isEmpty()) { toast("Pathanor moto kichu nai"); return; }
        copyText(s); // kono app share na nile paste kore dite parben
        hidePanel();
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, s);
        Intent chooser = Intent.createChooser(send, "Kothay pathaben?");
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(chooser);
        } catch (Exception e) {
            toast("Text copy hoyeche, chat-e paste kore din");
        }
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        CharSequence t = null;
        try {
            ClipData clip = cm != null ? cm.getPrimaryClip() : null;
            if (clip != null && clip.getItemCount() > 0) t = clip.getItemAt(0).coerceToText(this);
        } catch (Exception ignored) { }
        if (TextUtils.isEmpty(t)) {
            toast("Box-e long-press kore Paste chapun");
            input.requestFocus();
            return;
        }
        input.setText(t);
        inputFromScreen = false;
        input.setSelection(input.getText().length());
    }

    private void copyText(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("AI Bubble", s));
    }

    private void toggleProvider() {
        String next = "deepseek".equals(Prefs.provider(this)) ? "gemini" : "deepseek";
        Prefs.get(this).edit().putString(Prefs.PROVIDER, next).apply();
        refreshProviderChip();
        toast(Prefs.providerLabel(next) + " select hoyeche");
    }

    private void refreshProviderChip() {
        if (providerChip != null) providerChip.setText(Prefs.providerLabel(Prefs.provider(this)) + " ⇄");
    }

    private void selectLang(String code) {
        lang = code;
        Prefs.get(this).edit().putString(Prefs.LANG, code).apply();
        refreshLangButtons();
    }

    private void refreshLangButtons() {
        for (int i = 0; i < 3; i++) {
            boolean sel = LANG_CODES[i].equals(lang);
            langButtons[i].setBackground(rounded(sel ? DARK : 0xFFF1F5F9, dp(10)));
            langButtons[i].setTextColor(sel ? Color.WHITE : DARK);
        }
    }

    private void setButtonsEnabled(boolean on) {
        translateBtn.setEnabled(on);
        replyBtn.setEnabled(on);
        translateBtn.setAlpha(on ? 1f : 0.5f);
        replyBtn.setAlpha(on ? 1f : 0.5f);
    }

    private static String langName(String code) {
        for (int i = 0; i < LANG_CODES.length; i++) if (LANG_CODES[i].equals(code)) return LANG_NAMES[i];
        return LANG_NAMES[0];
    }

    // ------------------------------------------------------------------ ui helpers

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private LinearLayout.LayoutParams marginTop(int m) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = m;
        return lp;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(GREY);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        return t;
    }

    private EditText editBox(String hint, int minLines, int maxLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setMinLines(minLines);
        e.setMaxLines(maxLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setTextColor(DARK);
        e.setHintTextColor(0xFF94A3B8);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable bg = rounded(0xFFF8FAFC, dp(10));
        bg.setStroke(dp(1), 0xFFCBD5E1);
        e.setBackground(bg);
        return e;
    }

    private Button baseBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setStateListAnimator(null);
        return b;
    }

    private Button colorBtn(String text, int color) {
        Button b = baseBtn(text);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(rounded(color, dp(10)));
        return b;
    }

    private Button smallBtn(String text, View.OnClickListener l) {
        Button b = baseBtn(text);
        b.setTextColor(DARK);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setBackground(rounded(0xFFF1F5F9, dp(10)));
        b.setOnClickListener(l);
        return b;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private void safeUpdate(View v, WindowManager.LayoutParams lp) {
        try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
    }

    private int screenWidth() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
