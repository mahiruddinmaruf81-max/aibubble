package com.maruf.aibubble;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.util.Locale;

/**
 * Screen-er upore bhasha bubble, choto panel, ar notun message ashle popup.
 */
public class FloatingService extends Service {

    public static final String ACTION_STOP = "com.maruf.aibubble.STOP";
    public static final String ACTION_OPEN = "com.maruf.aibubble.OPEN";
    public static final String EXTRA_TEXT = "text";

    public static volatile boolean running = false;
    public static volatile FloatingService instance;

    private static final String[] LANG_CODES = {"auto", "bn", "en", "zh"};
    private static final String[] LANG_LABELS = {"Auto", "বাং", "EN", "中"};
    private static final String[] LANG_NAMES = {null, "Bengali (Bangla script)", "English", "Simplified Chinese"};

    private static final String SCREEN_NOTE = "The input is text read from the user's chat app screen, top to bottom. "
            + "It may contain names, times, dates, buttons and other app labels: ignore those. "
            + "Lines marked [right] are usually the user's OWN messages and [left] are the other person's. "
            + "Messages near the bottom are the newest. ";

    // Rong (light / dark)
    private int CARD, TEXT, SUB, FIELD, BORDER, CHIP, INFO_BG, INFO_TX;
    private static final int ACCENT = 0xFF2563EB, SEND = 0xFF7C3AED, GREEN = 0xFF16A34A, RED = 0xFFDC2626;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;

    // bubble
    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private boolean bubbleShown = false;
    private boolean tucked = false;          // double tap-e kinare lukano
    private long lastTapAt = 0;
    private final Runnable singleTap = () -> { if (!tucked) onBubbleTap(); };

    // panel
    private FrameLayout panelRoot;
    private LinearLayout card, inputBox, noticeBox;
    private WindowManager.LayoutParams panelLp;
    private boolean panelShown = false, panelClosing = false;
    private TextView providerChip, status, info, noticeText, noticeBtn;
    private EditText input, output;
    private final TextView[] langChips = new TextView[4];
    private String lang;
    private boolean inputFromScreen = false;
    private String replyKey = null;      // notification theke ashle sorasori reply
    private boolean busy = false;
    private long busyStart;
    private String busyLabel;
    private Runnable lastRun;
    private int jobId = 0;
    private String lastAiReply, lastAiMsg;   // shekhar jonno: AI ki likhechilo

    // popup (notun message)
    private FrameLayout popupRoot;
    private LinearLayout popupCard;
    private WindowManager.LayoutParams popupLp;
    private boolean popupShown = false;
    private TextView popTitle, popInfo, popReply, popStatus, popSend;
    private Incoming current;

    private TextToSpeech tts;
    private boolean ttsReady;
    private String pendingSpeak;

    private static final class Incoming {
        String key, app, sender, text, meaning, reply;
        boolean canReply;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ================================================================== lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        initColors();
        lang = Prefs.get(this).getString(Prefs.LANG, "auto");
        startAsForeground();
        try {
            createBubble();
            createPanel();
            createPopup();
            showBubble();
        } catch (Exception e) {
            Toast.makeText(this, "Bubble dekhano gelo na. \"Display over other apps\" permission din.",
                    Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP.equals(action)) {
                stopSelf();
                return START_NOT_STICKY;
            }
            if (ACTION_OPEN.equals(action) && card != null) {
                String t = intent.getStringExtra(EXTRA_TEXT);
                showPanel();
                if (t != null && !t.trim().isEmpty()) {
                    setInputBoxVisible(true);
                    input.setText(t);
                    inputFromScreen = false;
                    replyKey = null;
                    output.setText("");
                    setInfo(null, null);
                    runTranslate();
                }
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        instance = null;
        main.removeCallbacksAndMessages(null);
        try { if (bubbleShown) wm.removeView(bubble); } catch (Exception ignored) { }
        try { if (panelShown) wm.removeView(panelRoot); } catch (Exception ignored) { }
        try { if (popupShown) wm.removeView(popupRoot); } catch (Exception ignored) { }
        bubbleShown = panelShown = popupShown = false;
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    private void initColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        CARD = dark ? 0xFF1E293B : 0xFFFFFFFF;
        TEXT = dark ? 0xFFF1F5F9 : 0xFF0F172A;
        SUB = dark ? 0xFF94A3B8 : 0xFF64748B;
        FIELD = dark ? 0xFF0F172A : 0xFFF8FAFC;
        BORDER = dark ? 0xFF334155 : 0xFFE2E8F0;
        CHIP = dark ? 0xFF334155 : 0xFFF1F5F9;
        INFO_BG = dark ? 0xFF422006 : 0xFFFEF3C7;
        INFO_TX = dark ? 0xFFFDE68A : 0xFF78350F;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("bubble", "AI Bubble",
                NotificationManager.IMPORTANCE_LOW));
        int fl = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, FloatingService.class).setAction(ACTION_STOP), fl);
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class), fl);
        Notification n = new Notification.Builder(this, "bubble")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("AI Bubble chalu ache")
                .setContentText("Bubble-e tap korun: reply, translate, lens, voice")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat), "Bondho korun", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    // ================================================================== bubble

    private void createBubble() {
        final int size = dp(52);
        bubble = new TextView(this);
        bubble.setText("文A");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        bubble.setGravity(Gravity.CENTER);
        applyBubbleLook();

        bubbleLp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = Prefs.get(this).getInt("bx", screenWidth() - size);
        bubbleLp.y = Prefs.get(this).getInt("by", dp(220));
        tucked = Prefs.get(this).getBoolean("tucked", false);
        if (tucked) bubbleLp.x = edgeX(true);
        bubble.setAlpha(tucked ? 0.45f : 0.95f);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).start();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX, dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            if (tucked) setTucked(false, false);
                            bubbleLp.x = startX + (int) dx;
                            bubbleLp.y = Math.max(0, startY + (int) dy);
                            safeUpdate(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        float sc = tucked ? 0.85f : 1f;
                        v.animate().scaleX(sc).scaleY(sc).setDuration(140).start();
                        if (moved) {
                            snapToEdge();
                        } else if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                            long now = System.currentTimeMillis();
                            if (now - lastTapAt < 320) {
                                // double tap: lukano / ber kora
                                main.removeCallbacks(singleTap);
                                lastTapAt = 0;
                                setTucked(!tucked, true);
                            } else {
                                lastTapAt = now;
                                main.postDelayed(singleTap, 320);
                            }
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    /** Kon kinare ache (bam = true). */
    private boolean onLeft() {
        return bubbleLp.x + bubbleLp.width / 2 < screenWidth() / 2;
    }

    /** Kinar x: lukano hole ardhek-er beshi screen-er baire. */
    private int edgeX(boolean hide) {
        int w = screenWidth(), size = bubbleLp.width;
        boolean left = onLeft();
        if (hide) return left ? -(int) (size * 0.55f) : w - (int) (size * 0.45f);
        return left ? 0 : w - size;
    }

    private void setTucked(boolean t, boolean animate) {
        tucked = t;
        Prefs.get(this).edit().putBoolean("tucked", t).apply();
        float sc = t ? 0.85f : 1f;
        bubble.animate().alpha(t ? 0.45f : 0.95f).scaleX(sc).scaleY(sc).setDuration(200).start();
        if (animate) snapToEdge();
        if (animate && t) toast("Bubble lukano. Abar double tap korle beriye ashbe");
    }

    /** Bubble-er chhobi (nijer chhobi thakle sheta, na hole 文A). */
    public void applyBubbleLook() {
        if (bubble == null) return;
        Bitmap img = null;
        File f = new File(getFilesDir(), "bubble.png");
        if (f.exists()) img = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
        if (img != null) {
            bubble.setText("");
            bubble.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(), img));
        } else {
            bubble.setText("文A");
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(ACCENT);
            bg.setStroke(dp(2), Color.WHITE);
            bubble.setBackground(bg);
        }
    }

    private void snapToEdge() {
        int w = screenWidth(), size = bubbleLp.width;
        int target = edgeX(tucked);
        bubbleLp.y = Math.max(0, Math.min(bubbleLp.y, screenHeight() - size - dp(60)));
        ValueAnimator va = ValueAnimator.ofInt(bubbleLp.x, target);
        va.setDuration(300);
        va.setInterpolator(new OvershootInterpolator(1.0f));
        va.addUpdateListener(a -> {
            bubbleLp.x = (int) a.getAnimatedValue();
            if (bubbleShown) safeUpdate(bubble, bubbleLp);
        });
        va.start();
        Prefs.get(this).edit().putInt("bx", target).putInt("by", bubbleLp.y).apply();
    }

    private void showBubble() {
        if (bubbleShown || panelShown) return;
        try {
            wm.addView(bubble, bubbleLp);
            bubbleShown = true;
            bubble.setScaleX(0.3f);
            bubble.setScaleY(0.3f);
            float sc = tucked ? 0.85f : 1f;
            bubble.animate().scaleX(sc).scaleY(sc).setDuration(220)
                    .setInterpolator(new OvershootInterpolator(1.6f)).start();
        } catch (Exception ignored) { }
    }

    private void hideBubble() {
        if (bubbleShown) {
            try { wm.removeView(bubble); } catch (Exception ignored) { }
            bubbleShown = false;
        }
    }

    /** Lens / voice screen bondho hole bubble ferot. */
    public void showBubbleLater() {
        main.postDelayed(this::showBubble, 250);
    }

    private void onBubbleTap() {
        boolean auto = Prefs.get(this).getBoolean(Prefs.AUTO_READ, true);
        if (auto && ScreenReaderService.isOn() && Prefs.hasAnyKey(this)) {
            readScreenFlow();
        } else {
            showPanel();
        }
    }

    // ================================================================== panel

    private void createPanel() {
        panelRoot = new FrameLayout(this) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent ev) {
                if (ev.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                    if (ev.getAction() == KeyEvent.ACTION_UP) closePanel();
                    return true;
                }
                return super.dispatchKeyEvent(ev);
            }
        };
        panelRoot.setPadding(dp(8), dp(8), dp(8), dp(8));
        panelRoot.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_OUTSIDE) {
                if (!input.hasFocus() && !output.hasFocus()) closePanel();
                return true;
            }
            return false;
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(10));
        card.setBackground(rounded(CARD, dp(22), BORDER));
        scroll.addView(card);
        panelRoot.addView(scroll);

        // --- header: logo, bhasha, provider, close
        LinearLayout header = row();
        TextView logo = new TextView(this);
        logo.setText("文A");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable lbg = new GradientDrawable();
        lbg.setShape(GradientDrawable.OVAL);
        lbg.setColor(ACCENT);
        logo.setBackground(lbg);
        header.addView(logo, new LinearLayout.LayoutParams(dp(26), dp(26)));
        header.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));

        LinearLayout seg = row();
        seg.setPadding(dp(2), dp(2), dp(2), dp(2));
        seg.setBackground(rounded(CHIP, dp(10), 0));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView c = new TextView(this);
            c.setText(LANG_LABELS[i]);
            c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            c.setPadding(dp(9), dp(4), dp(9), dp(4));
            c.setOnClickListener(v -> selectLang(LANG_CODES[idx]));
            langChips[i] = c;
            seg.addView(c);
        }
        header.addView(seg);
        refreshLangChips();

        providerChip = new TextView(this);
        providerChip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        providerChip.setTextColor(ACCENT);
        providerChip.setPadding(dp(8), dp(4), dp(8), dp(4));
        providerChip.setBackground(rounded(CHIP, dp(10), 0));
        providerChip.setOnClickListener(v -> toggleProvider());
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2);
        plp.leftMargin = dp(6);
        header.addView(providerChip, plp);

        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        close.setTextColor(SUB);
        close.setPadding(dp(12), 0, dp(2), 0);
        close.setOnClickListener(v -> closePanel());
        header.addView(close);
        card.addView(header);

        // --- notice (setup baki thakle)
        noticeBox = new LinearLayout(this);
        noticeBox.setOrientation(LinearLayout.HORIZONTAL);
        noticeBox.setGravity(Gravity.CENTER_VERTICAL);
        noticeBox.setPadding(dp(10), dp(8), dp(8), dp(8));
        noticeBox.setBackground(rounded(INFO_BG, dp(12), 0));
        noticeText = new TextView(this);
        noticeText.setTextColor(INFO_TX);
        noticeText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        noticeBox.addView(noticeText, new LinearLayout.LayoutParams(0, -2, 1f));
        noticeBtn = pill("Chalu korun", ACCENT, Color.WHITE);
        noticeBox.addView(noticeBtn);
        noticeBox.setVisibility(View.GONE);
        card.addView(noticeBox, topMargin(dp(10)));

        // --- status (kaj cholche / error)
        status = new TextView(this);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        status.setTextColor(SUB);
        status.setVisibility(View.GONE);
        card.addView(status, topMargin(dp(8)));

        // --- ora ki bolche
        info = new TextView(this);
        info.setTextColor(INFO_TX);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        info.setPadding(dp(11), dp(8), dp(11), dp(8));
        info.setBackground(rounded(INFO_BG, dp(12), 0));
        info.setMaxLines(4);
        info.setEllipsize(TextUtils.TruncateAt.END);
        info.setOnClickListener(v -> info.setMaxLines(info.getMaxLines() == 4 ? 20 : 4));
        info.setVisibility(View.GONE);
        card.addView(info, topMargin(dp(8)));

        // --- reply / result
        output = field("Reply / translation ekhane ashbe", 2, 6);
        output.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        output.setOnFocusChangeListener((v, has) -> { if (has) movePanelTop(); });
        card.addView(output, topMargin(dp(8)));

        // --- input (lukano, ✏️ chaple ashe)
        inputBox = new LinearLayout(this);
        inputBox.setOrientation(LinearLayout.VERTICAL);
        input = field("Message likhun ba paste korun…", 2, 5);
        input.setOnFocusChangeListener((v, has) -> { if (has) movePanelTop(); });
        inputBox.addView(input, topMargin(0));
        LinearLayout inRow = row();
        inRow.addView(pillW("📋 Paste", CHIP, TEXT, v -> pasteClipboard()), weighted(dp(36)));
        inRow.addView(pillW("🌐 Translate", ACCENT, Color.WHITE, v -> runTranslate()), weighted(dp(36)));
        inRow.addView(pillW("💬 Reply", GREEN, Color.WHITE, v -> runReply()), weighted(dp(36)));
        inputBox.addView(inRow, topMargin(dp(6)));
        inputBox.setVisibility(View.GONE);
        card.addView(inputBox, topMargin(dp(8)));

        // --- tools
        LinearLayout tools = row();
        tools.addView(iconBtn("📱", "Screen pore reply", v -> readScreenFlow()), weighted(dp(42)));
        tools.addView(iconBtn("🔍", "Screen translate", v -> screenLens()), weighted(dp(42)));
        tools.addView(iconBtn("📷", "Chhobi translate", v -> openLens()), weighted(dp(42)));
        tools.addView(iconBtn("🎤", "Voice translate", v -> openVoice()), weighted(dp(42)));
        tools.addView(iconBtn("✏️", "Nije likhun", v -> setInputBoxVisible(inputBox.getVisibility() != View.VISIBLE)),
                weighted(dp(42)));
        tools.addView(iconBtn("🔄", "Abar", v -> { if (lastRun != null) lastRun.run(); }), weighted(dp(42)));
        card.addView(tools, topMargin(dp(10)));

        // --- bottom: shuno, copy, send
        LinearLayout bottom = row();
        bottom.addView(iconBtn("🔊", "Shunun", v -> speak(output.getText().toString())),
                new LinearLayout.LayoutParams(dp(46), dp(42)));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(46), dp(42));
        clp.leftMargin = dp(6);
        bottom.addView(iconBtn("⧉", "Copy", v -> copyOutput()), clp);
        TextView send = pill("Send  ➤", SEND, Color.WHITE);
        send.setTypeface(Typeface.DEFAULT_BOLD);
        send.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        send.setOnClickListener(v -> sendOutput());
        addPress(send);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        slp.leftMargin = dp(8);
        bottom.addView(send, slp);
        card.addView(bottom, topMargin(dp(8)));

        TextView stopLink = new TextView(this);
        stopLink.setText("Bubble bondho");
        stopLink.setTextColor(SUB);
        stopLink.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        stopLink.setGravity(Gravity.CENTER);
        stopLink.setPadding(0, dp(8), 0, 0);
        stopLink.setOnClickListener(v -> stopSelf());
        card.addView(stopLink);

        panelLp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN;
    }

    private void showPanel() {
        if (panelShown) {
            refreshNotice();
            return;
        }
        hideBubble();
        refreshProviderChip();
        refreshNotice();
        panelLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        panelLp.y = 0;
        panelLp.width = Math.min(screenWidth(), dp(520));
        try {
            wm.addView(panelRoot, panelLp);
            panelShown = true;
            panelClosing = false;
            card.setTranslationY(dp(90));
            card.setAlpha(0f);
            card.animate().translationY(0).alpha(1f).setDuration(220)
                    .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        } catch (Exception e) {
            toast("Panel khola gelo na");
            showBubble();
        }
    }

    private void closePanel() {
        if (!panelShown || panelClosing) return;
        panelClosing = true;
        hideKeyboard();
        card.animate().translationY(dp(90)).alpha(0f).setDuration(160).withEndAction(() -> {
            removePanelNow();
            showBubble();
        }).start();
    }

    /** Animation chara sathe sathe sorano (screenshot / onno screen kholar age). */
    private void removePanelNow() {
        if (!panelShown) return;
        hideKeyboard();
        try { wm.removeView(panelRoot); } catch (Exception ignored) { }
        panelShown = false;
        panelClosing = false;
        card.animate().cancel();
        card.setTranslationY(0);
        card.setAlpha(1f);
        input.clearFocus();
        output.clearFocus();
    }

    private void movePanelTop() {
        if (!panelShown || (panelLp.gravity & Gravity.VERTICAL_GRAVITY_MASK) == Gravity.TOP) return;
        panelLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelLp.y = dp(24);
        safeUpdate(panelRoot, panelLp);
    }

    private void setInputBoxVisible(boolean show) {
        inputBox.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            input.requestFocus();
            main.postDelayed(() -> {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(input, 0);
            }, 150);
        }
    }

    private void refreshNotice() {
        if (!Prefs.hasAnyKey(this)) {
            showNotice("API key nai. App khule DeepSeek / Gemini key din.", "Khulun", () -> openActivity(MainActivity.class));
        } else if (!ScreenReaderService.isOn()) {
            String msg = Prefs.a11yEnabledInSettings(this)
                    ? "Screen pora setting-e on, kintu phone bondho kore rekheche. Off kore abar on korun."
                    : "Screen pora bondho. Chalu korle bubble chaplei reply dekhabe.";
            showNotice(msg, "Chalu korun", () -> {
                removePanelNow();
                showBubble();
                Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(i); } catch (Exception ignored) { }
            });
        } else {
            noticeBox.setVisibility(View.GONE);
        }
    }

    private void showNotice(String text, String btn, Runnable r) {
        noticeText.setText(text);
        noticeBtn.setText(btn);
        noticeBtn.setOnClickListener(v -> r.run());
        noticeBox.setVisibility(View.VISIBLE);
    }

    // ================================================================== screen pora

    private boolean usable(String chat) {
        return chat != null && chat.replaceAll("\\s", "").length() >= 8;
    }

    /** Prothome lekha (accessibility), na hole screenshot theke lekha khuje reply. */
    private void readScreenFlow() {
        if (!ScreenReaderService.isOn()) {
            showPanel();
            refreshNotice();
            return;
        }
        String chat = ScreenReaderService.readChat();
        if (usable(chat)) {
            showPanel();
            fillFromScreen(chat);
            runReply();
        } else {
            screenshotReply();
        }
    }

    private void fillFromScreen(String chat) {
        input.setText(chat);
        inputFromScreen = true;
        replyKey = null;
        output.setText("");
        setInfo(null, null);
    }

    private void screenshotReply() {
        if (!ScreenReaderService.canShot()) {
            showPanel();
            showError("Screen-e lekha paoa gelo na. ✏️ chepe message paste korun.");
            return;
        }
        grabScreen(bm -> {
            showPanel();
            if (bm == null) {
                showError("Screenshot newa gelo na. ✏️ chepe message paste korun.");
                return;
            }
            setBusy("🔍 Screen-e lekha khujchi");
            final int w = bm.getWidth();
            Ocr.lines(bm, (items, err) -> {
                bm.recycle();
                busy = false;
                if (items.isEmpty()) {
                    stopBusy();
                    showError("Screen-e kono lekha paoa gelo na.");
                    return;
                }
                fillFromScreen(Ocr.chatText(items, w));
                runReply();
            });
        });
    }

    private interface ShotUser { void use(Bitmap bm); }

    /** Bubble/panel shoriye screenshot. */
    private void grabScreen(ShotUser user) {
        removePanelNow();
        hideBubble();
        if (popupShown) hidePopupNow();
        main.postDelayed(() -> ScreenReaderService.takeShot(user::use), 280);
    }

    /** 🔍 Screen-er upore translation (Lens). */
    private void screenLens() {
        if (!ScreenReaderService.canShot()) {
            showError(ScreenReaderService.isOn()
                    ? "Screen translate Android 11+ e kaj kore. 📷 diye chhobi tule korun."
                    : "Age \"Screen pora\" chalu korun.");
            if (!ScreenReaderService.isOn()) refreshNotice();
            return;
        }
        grabScreen(bm -> {
            if (bm == null) {
                showPanel();
                showError("Screenshot newa gelo na.");
                return;
            }
            try {
                File f = Media.saveJpeg(this, bm, "screen.jpg");
                bm.recycle();
                Intent i = new Intent(this, LensActivity.class);
                i.putExtra(LensActivity.EXTRA_PATH, f.getAbsolutePath());
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            } catch (Exception e) {
                showPanel();
                showError("Lens khola gelo na: " + e.getMessage());
            }
        });
    }

    private void openLens() {
        removePanelNow();
        hideBubble();
        Intent i = new Intent(this, LensActivity.class);
        i.putExtra(LensActivity.EXTRA_SOURCE, "camera");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try { startActivity(i); } catch (Exception e) { showBubble(); }
    }

    private void openVoice() {
        removePanelNow();
        hideBubble();
        Intent i = new Intent(this, ConversationActivity.class);
        i.putExtra(ConversationActivity.EXTRA_FOR_PANEL, true);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try { startActivity(i); } catch (Exception e) { showBubble(); }
    }

    /** Voice screen theke translation panel-e. */
    public void receiveText(String original, String translation) {
        main.postDelayed(() -> {
            showPanel();
            input.setText(original == null ? "" : original);
            inputFromScreen = false;
            replyKey = null;
            setInfo("🎤 Apni bollen: ", original);
            output.setText(translation);
            status.setVisibility(View.GONE);
        }, 300);
    }

    // ================================================================== AI kaj

    private static final class Result {
        String infoPrefix, info, output, provider, msg;
        boolean notFound, isReply;
    }

    private interface Job { Result run() throws Exception; }

    private void runJob(String label, Job job, Runnable onNotFound) {
        if (busy) return;
        final int my = ++jobId;
        setBusy(label);
        new Thread(() -> {
            Result r = null;
            String err = null;
            try {
                r = job.run();
            } catch (Exception e) {
                err = e.getMessage();
            }
            final Result fr = r;
            final String fe = err;
            main.post(() -> {
                if (my != jobId) return;
                busy = false;
                stopBusy();
                if (fe != null) {
                    showError(fe);
                } else if (fr.notFound) {
                    if (onNotFound != null) onNotFound.run();
                    else showError("Kono message paoa gelo na.");
                } else {
                    setInfo(fr.infoPrefix, fr.info);
                    output.setText(fr.output);
                    lastAiReply = fr.isReply ? fr.output : null;
                    lastAiMsg = fr.isReply ? fr.msg : null;
                    long s = (System.currentTimeMillis() - busyStart) / 1000;
                    status.setTextColor(GREEN);
                    status.setText("✓ " + fr.provider + " · " + s + "s");
                    status.setVisibility(View.VISIBLE);
                    output.setAlpha(0.3f);
                    output.animate().alpha(1f).setDuration(250).start();
                }
            });
        }).start();
    }

    private void setBusy(String label) {
        busy = true;
        busyLabel = label;
        busyStart = System.currentTimeMillis();
        status.setTextColor(SUB);
        status.setVisibility(View.VISIBLE);
        output.animate().alpha(0.45f).setDuration(200).start();
        main.removeCallbacks(ticker);
        main.post(ticker);
    }

    private void stopBusy() {
        main.removeCallbacks(ticker);
        output.animate().alpha(1f).setDuration(150).start();
    }

    private final Runnable ticker = new Runnable() {
        int i = 0;

        @Override
        public void run() {
            if (!busy) return;
            String[] dots = {"●○○", "○●○", "○○●", "○●○"};
            long s = (System.currentTimeMillis() - busyStart) / 1000;
            status.setText(busyLabel + "  " + dots[i++ % 4] + "  " + s + "s");
            main.postDelayed(this, 300);
        }
    };

    private void showError(String msg) {
        status.setTextColor(RED);
        status.setText("❌ " + msg);
        status.setVisibility(View.VISIBLE);
    }

    private String replyLang() {
        int i = langIndex();
        return i == 0 ? "in the same language the other person wrote in" : "in " + LANG_NAMES[i];
    }

    private String transLang() {
        int i = langIndex();
        return i == 0 ? "into English if the text is mainly Bengali, otherwise into Bengali (Bangla script)"
                : "into " + LANG_NAMES[i];
    }

    private String replySystem(boolean screen) {
        return "You help the user reply to chat messages. "
                + (screen
                ? SCREEN_NOTE + "Find the newest message(s) written by the OTHER person (not the user) and reply to them, "
                  + "using earlier messages only as context. If there is no message from another person, return {\"found\": false}. "
                : "The input is a message the user RECEIVED from someone. ")
                + "Return ONLY a JSON object: {\"found\": true, \"meaning\": a short Bengali (Bangla script) translation "
                + "of what the other person said, \"reply\": ONE short, natural, polite and friendly reply that the user "
                + "can send back, written " + replyLang() + "}. "
                + "Do not invent facts such as prices, dates or addresses; if needed keep the reply general or ask a short question."
                + Trainer.context(this);
    }

    private void runReply() {
        final String text = input.getText().toString().trim();
        if (text.isEmpty()) {
            setInputBoxVisible(true);
            toast("Age message paste korun ba likhun");
            return;
        }
        final boolean screen = inputFromScreen;
        final String sys = replySystem(screen);
        lastRun = this::runReply;
        runJob("💬 Reply banacchi", () -> {
            String[] r = AiClient.ask(getApplicationContext(), sys, text, true);
            Result res = new Result();
            res.provider = r[1];
            JSONObject j = AiClient.parseJson(r[0]);
            if (j == null) {
                res.output = r[0];
                return res;
            }
            if (!j.optBoolean("found", true)) {
                res.notFound = true;
                return res;
            }
            res.infoPrefix = "🗨 Ora bolche: ";
            res.info = j.optString("meaning", "");
            res.output = j.optString("reply", r[0]);
            res.isReply = true;
            res.msg = text;
            return res;
        }, screen ? this::screenshotReplyOrFail : null);
    }

    /** Lekha theke message na pele screenshot diye abar chesta. */
    private void screenshotReplyOrFail() {
        if (ScreenReaderService.canShot()) screenshotReply();
        else showError("Screen-e message paoa gelo na. ✏️ chepe paste korun.");
    }

    private void runTranslate() {
        final String text = input.getText().toString().trim();
        if (text.isEmpty()) {
            setInputBoxVisible(true);
            toast("Age lekha paste korun ba likhun");
            return;
        }
        final boolean screen = inputFromScreen;
        final String sys = "You are a professional translator. "
                + (screen ? SCREEN_NOTE + "Translate only the chat messages, one per line, without the [left]/[right] marks. " : "")
                + "Translate " + transLang() + ". Keep meaning, tone, names, numbers and emojis. "
                + "Output ONLY the translated text, with no explanations.";
        lastRun = this::runTranslate;
        runJob("🌐 Translate hocche", () -> {
            String[] r = AiClient.ask(getApplicationContext(), sys, text);
            Result res = new Result();
            res.provider = r[1];
            res.output = r[0];
            return res;
        }, null);
    }

    // ================================================================== notun message popup

    private void createPopup() {
        popupRoot = new FrameLayout(this);
        popupRoot.setPadding(dp(8), dp(4), dp(8), dp(8));
        popupCard = new LinearLayout(this);
        popupCard.setOrientation(LinearLayout.VERTICAL);
        popupCard.setPadding(dp(14), dp(10), dp(14), dp(12));
        popupCard.setBackground(rounded(CARD, dp(20), BORDER));
        popupRoot.addView(popupCard);

        LinearLayout head = row();
        popTitle = new TextView(this);
        popTitle.setTextColor(TEXT);
        popTitle.setTypeface(Typeface.DEFAULT_BOLD);
        popTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        popTitle.setSingleLine(true);
        popTitle.setEllipsize(TextUtils.TruncateAt.END);
        head.addView(popTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = new TextView(this);
        x.setText("✕");
        x.setTextColor(SUB);
        x.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        x.setPadding(dp(12), 0, 0, 0);
        x.setOnClickListener(v -> hidePopup());
        head.addView(x);
        popupCard.addView(head);

        popInfo = new TextView(this);
        popInfo.setTextColor(INFO_TX);
        popInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        popInfo.setMaxLines(3);
        popInfo.setEllipsize(TextUtils.TruncateAt.END);
        popInfo.setPadding(dp(10), dp(6), dp(10), dp(6));
        popInfo.setBackground(rounded(INFO_BG, dp(10), 0));
        popupCard.addView(popInfo, topMargin(dp(6)));

        popReply = new TextView(this);
        popReply.setTextColor(TEXT);
        popReply.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        popReply.setMaxLines(4);
        popReply.setEllipsize(TextUtils.TruncateAt.END);
        popReply.setPadding(dp(10), dp(7), dp(10), dp(7));
        popReply.setBackground(rounded(FIELD, dp(10), BORDER));
        popupCard.addView(popReply, topMargin(dp(6)));

        popStatus = new TextView(this);
        popStatus.setTextColor(SUB);
        popStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        popupCard.addView(popStatus, topMargin(dp(4)));

        LinearLayout btns = row();
        btns.addView(pillW("✏️ Edit", CHIP, TEXT, v -> editIncoming()), weighted(dp(38)));
        btns.addView(pillW("🔄 Onno", CHIP, TEXT, v -> { if (current != null) makeIncomingReply(current); }),
                weighted(dp(38)));
        popSend = pillW("Send ➤", SEND, Color.WHITE, v -> sendIncoming());
        popSend.setTypeface(Typeface.DEFAULT_BOLD);
        btns.addView(popSend, weighted(dp(38)));
        popupCard.addView(btns, topMargin(dp(8)));

        popupCard.setOnClickListener(v -> editIncoming());

        popupLp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        popupLp.gravity = Gravity.TOP;
        popupLp.y = dp(28);
    }

    /** MsgListenerService theke: notun message. */
    public void onIncoming(String key, String app, String pkg, String sender, String text, boolean canReply) {
        main.post(() -> {
            if (!Prefs.hasAnyKey(this) || popupRoot == null) return;
            Incoming in = new Incoming();
            in.key = key;
            in.app = app;
            in.sender = sender;
            in.text = text;
            in.canReply = canReply;
            current = in;
            popTitle.setText(app + " · " + sender);
            popInfo.setText("🗨 " + text);
            popReply.setText("…");
            showPopup();
            makeIncomingReply(in);
        });
    }

    private void makeIncomingReply(Incoming in) {
        popStatus.setTextColor(SUB);
        popStatus.setText("⏳ Reply banacchi…");
        popSend.setAlpha(0.5f);
        in.reply = null;
        final String sys = replySystem(false);
        final String msg = "Message from " + in.sender + ":\n" + in.text;
        new Thread(() -> {
            String err = null, meaning = null, reply = null, prov = null;
            try {
                String[] r = AiClient.ask(getApplicationContext(), sys, msg, true);
                prov = r[1];
                JSONObject j = AiClient.parseJson(r[0]);
                meaning = j != null ? j.optString("meaning", "") : "";
                reply = j != null ? j.optString("reply", r[0]) : r[0];
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fe = err, fm = meaning, fr = reply, fp = prov;
            main.post(() -> {
                if (current != in) return;
                if (fe != null) {
                    popStatus.setTextColor(RED);
                    popStatus.setText("❌ " + fe);
                    return;
                }
                in.meaning = fm;
                in.reply = fr;
                if (fm != null && !fm.isEmpty()) popInfo.setText("🗨 " + fm);
                popReply.setText(fr);
                popSend.setAlpha(1f);
                boolean canSend = in.canReply && MsgListenerService.canReply(in.key);
                popStatus.setTextColor(SUB);
                popStatus.setText(fp + " · " + (canSend ? "Send chaple sorasori " + in.app + "-e jabe"
                        : "Send chaple share menu khulbe"));
                if (canSend && Prefs.get(this).getBoolean(Prefs.AUTO_SEND, false)
                        && MsgListenerService.autoSendAllowed(in.key)) {
                    if (MsgListenerService.sendReply(this, in.key, fr)) {
                        popStatus.setTextColor(GREEN);
                        popStatus.setText("✓ Nije nije pathano hoyeche");
                        main.postDelayed(() -> { if (current == in) hidePopup(); }, 5000);
                    }
                }
            });
        }).start();
    }

    private void sendIncoming() {
        Incoming in = current;
        if (in == null || in.reply == null) return;
        if (in.canReply && MsgListenerService.sendReply(this, in.key, in.reply)) {
            toast("✓ Pathano hoyeche");
            hidePopup();
            return;
        }
        hidePopup();
        share(in.reply);
    }

    private void editIncoming() {
        Incoming in = current;
        if (in == null) return;
        hidePopupNow();
        showPanel();
        input.setText(in.text);
        inputFromScreen = false;
        replyKey = in.canReply ? in.key : null;
        setInfo("🗨 Ora bolche: ", in.meaning != null && !in.meaning.isEmpty() ? in.meaning : in.text);
        output.setText(in.reply == null ? "" : in.reply);
        status.setVisibility(View.GONE);
        lastRun = this::runReply;
        lastAiReply = in.reply;
        lastAiMsg = in.text;
    }

    private void showPopup() {
        if (popupShown) {
            popupCard.setTranslationX(dp(8));
            popupCard.animate().translationX(0).setDuration(150).start();
            return;
        }
        try {
            wm.addView(popupRoot, popupLp);
            popupShown = true;
            popupCard.setTranslationY(-dp(80));
            popupCard.setAlpha(0f);
            popupCard.animate().translationY(0).alpha(1f).setDuration(240)
                    .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        } catch (Exception ignored) { }
    }

    private void hidePopup() {
        if (!popupShown) return;
        popupCard.animate().translationY(-dp(80)).alpha(0f).setDuration(160)
                .withEndAction(this::hidePopupNow).start();
    }

    private void hidePopupNow() {
        if (!popupShown) return;
        try { wm.removeView(popupRoot); } catch (Exception ignored) { }
        popupShown = false;
        popupCard.animate().cancel();
        popupCard.setTranslationY(0);
        popupCard.setAlpha(1f);
        current = null;
    }

    // ================================================================== chotokhato kaj

    private void sendOutput() {
        String s = output.getText().toString().trim();
        if (s.isEmpty()) s = input.getText().toString().trim();
        if (s.isEmpty()) {
            toast("Pathanor moto kichu nai");
            return;
        }
        // Apni AI-er reply bodle thakle sheta shekha
        if (lastAiReply != null && !s.equals(lastAiReply.trim()) && Trainer.learnOn(this)) {
            Trainer.learn(this, lastAiMsg, s);
            toast("🧠 Shikhe nilam");
        }
        lastAiReply = null;
        if (replyKey != null && MsgListenerService.sendReply(this, replyKey, s)) {
            replyKey = null;
            toast("✓ Pathano hoyeche");
            closePanel();
            return;
        }
        removePanelNow();
        showBubble();
        share(s);
    }

    private void share(String s) {
        copyText(s);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, s);
        Intent chooser = Intent.createChooser(send, "Kothay pathaben?");
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(chooser);
        } catch (Exception e) {
            toast("Copy hoyeche, chat-e paste kore din");
        }
    }

    private void copyOutput() {
        String s = output.getText().toString().trim();
        if (s.isEmpty()) {
            toast("Ekhono kichu nai");
            return;
        }
        copyText(s);
        toast("Copy hoyeche");
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        CharSequence t = null;
        try {
            ClipData clip = cm != null ? cm.getPrimaryClip() : null;
            if (clip != null && clip.getItemCount() > 0) t = clip.getItemAt(0).coerceToText(this);
        } catch (Exception ignored) { }
        if (TextUtils.isEmpty(t)) {
            toast("Box-e long-press kore Paste chapun");
            input.requestFocus();
            return;
        }
        input.setText(t);
        inputFromScreen = false;
        replyKey = null;
        input.setSelection(input.getText().length());
    }

    private void copyText(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("AI Bubble", s));
    }

    private void setInfo(String prefix, String text) {
        if (TextUtils.isEmpty(text)) {
            info.setText("");
            info.setVisibility(View.GONE);
        } else {
            info.setText((prefix == null ? "" : prefix) + text);
            info.setMaxLines(4);
            info.setVisibility(View.VISIBLE);
        }
    }

    private void toggleProvider() {
        String p = Prefs.provider(this);
        String next = "auto".equals(p) ? "deepseek" : ("deepseek".equals(p) ? "gemini" : "auto");
        Prefs.get(this).edit().putString(Prefs.PROVIDER, next).apply();
        refreshProviderChip();
        toast(Prefs.providerLabel(next) + (("auto".equals(next)) ? ": je kaj kore sheta" : ""));
    }

    private void refreshProviderChip() {
        String p = Prefs.provider(this);
        providerChip.setText("auto".equals(p) ? "⚡ Auto" : ("gemini".equals(p) ? "Gemini" : "DeepSeek"));
    }

    private void selectLang(String code) {
        lang = code;
        Prefs.get(this).edit().putString(Prefs.LANG, code).apply();
        refreshLangChips();
    }

    private int langIndex() {
        for (int i = 0; i < LANG_CODES.length; i++) if (LANG_CODES[i].equals(lang)) return i;
        return 0;
    }

    private void refreshLangChips() {
        int sel = langIndex();
        for (int i = 0; i < 4; i++) {
            boolean on = i == sel;
            langChips[i].setBackground(on ? rounded(TEXT, dp(8), 0) : null);
            langChips[i].setTextColor(on ? CARD : SUB);
        }
    }

    // ---- shuno (text-to-speech)

    private void speak(String s) {
        if (TextUtils.isEmpty(s)) {
            toast("Ekhono kichu nai");
            return;
        }
        if (tts == null) {
            pendingSpeak = s;
            tts = new TextToSpeech(getApplicationContext(), st -> main.post(() -> {
                ttsReady = st == TextToSpeech.SUCCESS;
                if (!ttsReady) toast("Phone-e text-to-speech nai");
                else if (pendingSpeak != null) {
                    doSpeak(pendingSpeak);
                    pendingSpeak = null;
                }
            }));
            return;
        }
        if (!ttsReady) {
            pendingSpeak = s;
            return;
        }
        doSpeak(s);
    }

    private void doSpeak(String s) {
        Locale loc;
        if (s.matches("(?s).*[\\u0980-\\u09FF].*")) loc = Locale.forLanguageTag("bn-BD");
        else if (s.matches("(?s).*[\\u4E00-\\u9FFF].*")) loc = Locale.SIMPLIFIED_CHINESE;
        else loc = Locale.US;
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("Ei bhashar voice phone-e nai (Settings → Text-to-speech)");
            return;
        }
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "bubble");
    }

    // ================================================================== ui helpers

    private void openActivity(Class<?> cls) {
        removePanelNow();
        showBubble();
        Intent i = new Intent(this, cls);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception ignored) { }
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && panelRoot != null) imm.hideSoftInputFromWindow(panelRoot.getWindowToken(), 0);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams weighted(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, h, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private LinearLayout.LayoutParams topMargin(int m) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = m;
        return lp;
    }

    private EditText field(String hint, int minLines, int maxLines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setMinLines(minLines);
        e.setMaxLines(maxLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setTextColor(TEXT);
        e.setHintTextColor(SUB);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        e.setPadding(dp(11), dp(9), dp(11), dp(9));
        e.setBackground(rounded(FIELD, dp(12), BORDER));
        return e;
    }

    private TextView iconBtn(String emoji, String desc, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(emoji);
        t.setContentDescription(desc);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setGravity(Gravity.CENTER);
        t.setBackground(rounded(CHIP, dp(14), 0));
        t.setOnClickListener(l);
        t.setOnLongClickListener(v -> {
            toast(desc);
            return true;
        });
        addPress(t);
        return t;
    }

    private TextView pill(String s, int bg, int fg) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(fg);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(6), dp(12), dp(6));
        t.setBackground(rounded(bg, dp(21), 0));
        return t;
    }

    private TextView pillW(String s, int bg, int fg, View.OnClickListener l) {
        TextView t = pill(s, bg, fg);
        t.setOnClickListener(l);
        addPress(t);
        return t;
    }

    private void addPress(View v) {
        v.setOnTouchListener((vv, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) vv.animate().scaleX(0.93f).scaleY(0.93f).setDuration(70).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                vv.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return false;
        });
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private void safeUpdate(View v, WindowManager.LayoutParams lp) {
        try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
    }

    private int screenWidth() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenHeight() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
