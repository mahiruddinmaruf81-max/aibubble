package com.maruf.aibubble;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Lens: chhobi (camera / gallery / screen) theke lekha khuje, thik oi jaygay translation boshay.
 */
public class LensActivity extends Activity {

    public static final String EXTRA_PATH = "path";     // screenshot file
    public static final String EXTRA_SOURCE = "source"; // "camera" ba "gallery"

    private static final int REQ_CAMERA = 11, REQ_GALLERY = 12;
    private static final String[] TARGET_LABELS = {"বাংলা", "English", "中文"};
    private static final String[] TARGET_NAMES = {"Bengali (Bangla script)", "English", "Simplified Chinese"};

    private final Handler main = new Handler(Looper.getMainLooper());
    private LensView lens;
    private TextView status, eye;
    private final TextView[] targetChips = new TextView[3];
    private int target;
    private List<Ocr.Item> items;
    private Uri cameraUri;
    private int job = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        target = Prefs.get(this).getInt("lens_target", 0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        lens = new LensView(this);
        lens.setOnItemTap(this::showItem);
        root.addView(lens, new FrameLayout.LayoutParams(-1, -1));

        // Upore bar
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(10), dp(10), dp(10), dp(10));
        top.setBackgroundColor(0xB3000000);
        TextView close = pill("✕", 0x33FFFFFF);
        close.setOnClickListener(v -> finish());
        top.addView(close);
        TextView title = new TextView(this);
        title.setText("  Lens");
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView chip = pill(TARGET_LABELS[i], 0x33FFFFFF);
            chip.setOnClickListener(v -> setTarget(idx));
            targetChips[i] = chip;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = dp(4);
            top.addView(chip, lp);
        }
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        refreshTargets();

        // Niche bar
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(12), dp(10), dp(12), dp(14));
        bottom.setBackgroundColor(0xB3000000);
        status = new TextView(this);
        status.setTextColor(0xFFE2E8F0);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        status.setGravity(Gravity.CENTER);
        bottom.addView(status, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(10), 0, 0);
        TextView cam = pill("📷  Camera", 0xFF2563EB);
        cam.setOnClickListener(v -> openCamera());
        TextView gal = pill("🖼  Gallery", 0x33FFFFFF);
        gal.setOnClickListener(v -> openGallery());
        eye = pill("👁  Asol", 0x33FFFFFF);
        eye.setOnClickListener(v -> {
            lens.setShowOriginal(!lens.isShowingOriginal());
            eye.setText(lens.isShowingOriginal() ? "🌐  Translate" : "👁  Asol");
        });
        TextView copy = pill("⧉  Copy", 0x33FFFFFF);
        copy.setOnClickListener(v -> copyAll());
        for (TextView t : new TextView[]{cam, gal, eye, copy}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            row.addView(t, lp);
        }
        bottom.addView(row);
        root.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        setContentView(root);

        String path = getIntent().getStringExtra(EXTRA_PATH);
        String source = getIntent().getStringExtra(EXTRA_SOURCE);
        if (path != null) {
            Bitmap bm = Media.loadFile(path, 2000);
            if (bm != null) setImage(bm);
            else status.setText("Chhobi khola gelo na");
        } else if ("gallery".equals(source)) {
            openGallery();
        } else if ("camera".equals(source)) {
            openCamera();
        } else {
            status.setText("Camera diye chhobi tulun ba Gallery theke din");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FloatingService fs = FloatingService.instance;
        if (fs != null) fs.showBubbleLater();
    }

    // ------------------------------------------------------------- chhobi newa

    private void openCamera() {
        if (Build.VERSION.SDK_INT < 29) {
            toast("Ei phone-e Gallery use korun");
            openGallery();
            return;
        }
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "lens_" + System.currentTimeMillis() + ".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AiBubble");
            cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMERA);
        } catch (Exception e) {
            toast("Camera khola gelo na, Gallery use korun");
        }
    }

    private void openGallery() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_GALLERY);
        } catch (Exception e) {
            toast("Gallery khola gelo na");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        Uri uri = null;
        if (req == REQ_CAMERA) {
            if (res == RESULT_OK) uri = cameraUri;
            else if (cameraUri != null) {
                try { getContentResolver().delete(cameraUri, null, null); } catch (Exception ignored) { }
            }
        } else if (req == REQ_GALLERY && res == RESULT_OK && data != null) {
            uri = data.getData();
        }
        if (uri == null) {
            if (lens.getBitmap() == null) status.setText("Camera diye chhobi tulun ba Gallery theke din");
            return;
        }
        status.setText("⏳ Chhobi khulchi…");
        final Uri u = uri;
        new Thread(() -> {
            try {
                Bitmap bm = Media.loadUri(this, u, 2000);
                main.post(() -> setImage(bm));
            } catch (Exception e) {
                main.post(() -> status.setText("❌ " + e.getMessage()));
            }
        }).start();
    }

    // ------------------------------------------------------------- lekha khoja + translate

    private void setImage(Bitmap bm) {
        lens.setBitmap(bm);
        lens.setShowOriginal(false);
        eye.setText("👁  Asol");
        items = null;
        final int my = ++job;
        status.setText("🔍 Lekha khujchi…");
        Ocr.blocks(bm, (list, err) -> {
            if (my != job) return;
            if (err != null) {
                status.setText("❌ Lekha khoja gelo na: " + err.getMessage());
                return;
            }
            if (list.isEmpty()) {
                status.setText("Chhobi-te kono lekha paoa gelo na");
                return;
            }
            items = list;
            lens.setItems(list);
            translate();
        });
    }

    private void translate() {
        if (items == null || items.isEmpty()) return;
        final int my = ++job;
        final List<Ocr.Item> list = items;
        status.setText("🌐 " + list.size() + " ta lekha " + TARGET_LABELS[target] + "-e translate hocche…");
        final String name = TARGET_NAMES[target];
        new Thread(() -> {
            try {
                String prov = Ocr.translate(getApplicationContext(), list, name);
                main.post(() -> {
                    if (my != job) return;
                    lens.refresh();
                    status.setText("✓ " + list.size() + " ta lekha · " + prov + " · lekhay tap korle bistarito");
                });
            } catch (Exception e) {
                main.post(() -> {
                    if (my != job) return;
                    status.setText("❌ " + e.getMessage());
                });
            }
        }).start();
    }

    private void setTarget(int idx) {
        if (idx == target) return;
        target = idx;
        Prefs.get(this).edit().putInt("lens_target", idx).apply();
        refreshTargets();
        if (items != null) {
            for (Ocr.Item it : items) it.translated = null;
            lens.refresh();
            translate();
        }
    }

    private void refreshTargets() {
        for (int i = 0; i < 3; i++) {
            boolean sel = i == target;
            targetChips[i].setBackground(round(sel ? Color.WHITE : 0x33FFFFFF, dp(14)));
            targetChips[i].setTextColor(sel ? 0xFF0F172A : Color.WHITE);
        }
    }

    private void showItem(Ocr.Item it) {
        String tr = it.translated == null ? "" : it.translated;
        new AlertDialog.Builder(this)
                .setTitle(tr.isEmpty() ? "Lekha" : tr)
                .setMessage(it.text)
                .setPositiveButton("Copy", (d, w) -> copy(tr.isEmpty() ? it.text : tr))
                .setNegativeButton("Bondho", null)
                .show();
    }

    private void copyAll() {
        if (items == null || items.isEmpty()) {
            toast("Ekhono kono lekha nai");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Ocr.Item it : items) {
            sb.append(it.text);
            if (it.translated != null && !it.translated.isEmpty()) sb.append("\n→ ").append(it.translated);
            sb.append("\n\n");
        }
        copy(sb.toString().trim());
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Lens", s));
        toast("Copy hoyeche");
    }

    // ------------------------------------------------------------- ui helpers

    private TextView pill(String s, int bg) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        t.setBackground(round(bg, dp(21)));
        return t;
    }

    private GradientDrawable round(int color, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(r);
        return d;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
