package com.maruf.aibubble;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * DeepSeek ba Gemini API call kore. Selected provider fail korle
 * onno provider-er key thakle sheta diye abar try kore.
 * Network call, tai background thread theke call korte hobe.
 */
public final class AiClient {

    private AiClient() {}

    /** @return [0] = AI-er uttor, [1] = kon provider use hoyeche */
    public static String[] ask(Context c, String system, String user) throws Exception {
        SharedPreferences p = Prefs.get(c);
        String first = Prefs.provider(c);
        String second = "deepseek".equals(first) ? "gemini" : "deepseek";

        Exception firstError = null;
        for (String prov : new String[]{first, second}) {
            boolean isDs = "deepseek".equals(prov);
            String key = p.getString(isDs ? Prefs.DS_KEY : Prefs.GM_KEY, "").trim();
            if (key.isEmpty()) continue;
            String model = p.getString(isDs ? Prefs.DS_MODEL : Prefs.GM_MODEL, "").trim();
            if (model.isEmpty()) model = isDs ? Prefs.DEFAULT_DS_MODEL : Prefs.DEFAULT_GM_MODEL;
            try {
                String out = isDs ? deepseek(key, model, system, user) : gemini(key, model, system, user);
                return new String[]{out.trim(), Prefs.providerLabel(prov)};
            } catch (Exception e) {
                if (firstError == null) {
                    firstError = new Exception(Prefs.providerLabel(prov) + ": " + e.getMessage());
                }
            }
        }
        if (firstError != null) throw firstError;
        throw new Exception("Kono API key set kora nai. AI Bubble app khule DeepSeek ba Gemini key din.");
    }

    // ---------- DeepSeek (OpenAI-compatible) ----------
    private static String deepseek(String key, String model, String system, String user) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", system));
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        body.put("messages", msgs);
        body.put("temperature", 0.3);
        body.put("stream", false);

        String resp = post("https://api.deepseek.com/chat/completions", body.toString(),
                new String[][]{{"Authorization", "Bearer " + key}});
        JSONObject json = new JSONObject(resp);
        JSONArray choices = json.optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new Exception("Khali uttor elo");
        return choices.getJSONObject(0).getJSONObject("message").optString("content", "");
    }

    // ---------- Google Gemini ----------
    private static String gemini(String key, String model, String system, String user) throws Exception {
        JSONObject body = new JSONObject();
        body.put("system_instruction", new JSONObject()
                .put("parts", new JSONArray().put(new JSONObject().put("text", system))));
        body.put("contents", new JSONArray().put(new JSONObject()
                .put("role", "user")
                .put("parts", new JSONArray().put(new JSONObject().put("text", user)))));
        body.put("generationConfig", new JSONObject().put("temperature", 0.3));

        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
        String resp = post(url, body.toString(), new String[][]{{"x-goog-api-key", key}});
        JSONObject json = new JSONObject(resp);
        JSONArray cands = json.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) {
            JSONObject fb = json.optJSONObject("promptFeedback");
            String reason = fb != null ? fb.optString("blockReason", "") : "";
            throw new Exception(reason.isEmpty() ? "Khali uttor elo" : "Block hoyeche: " + reason);
        }
        JSONObject content = cands.getJSONObject(0).optJSONObject("content");
        JSONArray parts = content != null ? content.optJSONArray("parts") : null;
        if (parts == null) throw new Exception("Khali uttor elo");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            JSONObject part = parts.getJSONObject(i);
            if (part.optBoolean("thought", false)) continue;
            sb.append(part.optString("text", ""));
        }
        return sb.toString();
    }

    // ---------- HTTP ----------
    private static String post(String url, String body, String[][] headers) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        try {
            con.setRequestMethod("POST");
            con.setConnectTimeout(20000);
            con.setReadTimeout(90000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            for (String[] h : headers) con.setRequestProperty(h[0], h[1]);
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = con.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? con.getInputStream() : con.getErrorStream();
            String resp = is == null ? "" : readAll(is);
            if (code < 200 || code >= 300) {
                throw new Exception(friendly(code) + " " + shortError(resp));
            }
            return resp;
        } finally {
            con.disconnect();
        }
    }

    private static String friendly(int code) {
        switch (code) {
            case 400: return "(400) Request bhul / model naam bhul hote pare.";
            case 401:
            case 403: return "(" + code + ") API key bhul ba permission nai.";
            case 402: return "(402) Account-e balance nai.";
            case 404: return "(404) Model naam paoa jay nai.";
            case 429: return "(429) Limit shesh, ektu pore try korun.";
            default: return "(HTTP " + code + ")";
        }
    }

    private static String shortError(String resp) {
        try {
            JSONObject j = new JSONObject(resp);
            Object err = j.opt("error");
            if (err instanceof JSONObject) return ((JSONObject) err).optString("message", "");
            if (err != null) return err.toString();
        } catch (Exception ignored) { }
        return resp.length() > 200 ? resp.substring(0, 200) : resp;
    }

    private static String readAll(InputStream is) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }
}
