package com.maruf.aibubble;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLException;

/**
 * DeepSeek + Gemini eksathe.
 * "Auto": je API ekhon kaj korche sheta use kore. VPN off thakle Gemini-te connect hoy na,
 * tokhon sathe sathe DeepSeek, ar kichukkhon Gemini-ke "bondho" dhore rakhe jate opekkha na korte hoy.
 * Background thread theke call korte hobe.
 */
public final class AiClient {

    private AiClient() {}

    private static volatile long dsDownUntil = 0, gmDownUntil = 0;
    private static volatile String lastGood = "deepseek";
    private static volatile boolean thinkingParamOk = true;

    /** Network-er karone fail (VPN nai, internet nai, timeout). */
    private static final class NetErr extends Exception {
        NetErr(String m) { super(m); }
    }

    public static String[] ask(Context c, String system, String user) throws Exception {
        return ask(c, system, user, false);
    }

    /** @return [0] = uttor, [1] = provider naam */
    public static String[] ask(Context c, String system, String user, boolean json) throws Exception {
        SharedPreferences p = Prefs.get(c);
        String dsKey = p.getString(Prefs.DS_KEY, "").trim();
        String gmKey = p.getString(Prefs.GM_KEY, "").trim();
        if (dsKey.isEmpty() && gmKey.isEmpty()) {
            throw new Exception("Kono API key nai. AI Bubble app khule DeepSeek ba Gemini key din.");
        }

        List<String> order = order(Prefs.provider(c), !dsKey.isEmpty(), !gmKey.isEmpty());
        Exception firstError = null;
        for (int i = 0; i < order.size(); i++) {
            String prov = order.get(i);
            boolean isDs = "deepseek".equals(prov);
            String key = isDs ? dsKey : gmKey;
            String model = model(p, isDs);
            boolean onlyOne = order.size() == 1;
            try {
                String out = call(isDs, key, model, system, user, json, onlyOne);
                markGood(prov);
                return new String[]{out.trim(), Prefs.providerLabel(prov)};
            } catch (Exception e) {
                markBad(prov, e);
                if (firstError == null) firstError = new Exception(label(prov, e));
            }
        }
        throw firstError;
    }

    /** Voice-er moto media (shudhu Gemini bujhe). */
    public static String[] askMedia(Context c, String system, String user, String mime, String base64,
                                    boolean json) throws Exception {
        SharedPreferences p = Prefs.get(c);
        String key = p.getString(Prefs.GM_KEY, "").trim();
        if (key.isEmpty()) throw new Exception("Ei kaj-er jonno Gemini key lagbe.");
        try {
            String out = gemini(key, model(p, false), system, user, mime, base64, json);
            markGood("gemini");
            return new String[]{out.trim(), "Gemini"};
        } catch (Exception e) {
            markBad("gemini", e);
            throw new Exception(label("gemini", e));
        }
    }

    /** Gemini ekhon reach kora jabe mone hocche kina (VPN ache kina). */
    public static boolean geminiLikelyUp() {
        return System.currentTimeMillis() > gmDownUntil;
    }

    private static List<String> order(String pref, boolean hasDs, boolean hasGm) {
        long now = System.currentTimeMillis();
        List<String> list = new ArrayList<>();
        String first;
        if ("gemini".equals(pref)) first = "gemini";
        else if ("deepseek".equals(pref)) first = "deepseek";
        else first = lastGood; // auto
        String second = "deepseek".equals(first) ? "gemini" : "deepseek";
        // Auto mode-e jeta "down" sheta pore
        if ("auto".equals(pref)) {
            boolean firstDown = "deepseek".equals(first) ? now < dsDownUntil : now < gmDownUntil;
            boolean secondDown = "deepseek".equals(second) ? now < dsDownUntil : now < gmDownUntil;
            if (firstDown && !secondDown) { String t = first; first = second; second = t; }
        }
        for (String s : new String[]{first, second}) {
            if ("deepseek".equals(s) && hasDs) list.add(s);
            if ("gemini".equals(s) && hasGm) list.add(s);
        }
        return list;
    }

    private static void markGood(String prov) {
        lastGood = prov;
        if ("deepseek".equals(prov)) dsDownUntil = 0; else gmDownUntil = 0;
    }

    private static void markBad(String prov, Exception e) {
        long now = System.currentTimeMillis();
        long until;
        if (e instanceof NetErr) until = now + 3 * 60_000;          // VPN / net nai: 3 min
        else if (busy(e)) until = now + 60_000;                      // server byasto: 1 min
        else return;
        if ("deepseek".equals(prov)) dsDownUntil = until; else gmDownUntil = until;
    }

    private static boolean busy(Exception e) {
        String m = String.valueOf(e.getMessage());
        return m.contains("503") || m.contains("HTTP 500") || m.contains("(429)") || m.contains("HTTP 502");
    }

    private static String label(String prov, Exception e) {
        String name = Prefs.providerLabel(prov);
        if (e instanceof NetErr) {
            return name + ": connect hocche na" + ("gemini".equals(prov) ? " (VPN on ache?)" : " (internet check korun)");
        }
        return name + ": " + e.getMessage();
    }

    private static String model(SharedPreferences p, boolean isDs) {
        String m = p.getString(isDs ? Prefs.DS_MODEL : Prefs.GM_MODEL, "").trim();
        if (m.startsWith("models/")) m = m.substring(7);
        m = m.replace(' ', '-').toLowerCase();
        if (m.isEmpty()) m = isDs ? Prefs.DEFAULT_DS_MODEL : Prefs.DEFAULT_GM_MODEL;
        return m;
    }

    private static String call(boolean isDs, String key, String model, String system, String user,
                               boolean json, boolean retryIfBusy) throws Exception {
        try {
            return isDs ? deepseek(key, model, system, user, json)
                    : gemini(key, model, system, user, null, null, json);
        } catch (Exception e) {
            if (!retryIfBusy || !busy(e)) throw e;
            Thread.sleep(1500);
            return isDs ? deepseek(key, model, system, user, json)
                    : gemini(key, model, system, user, null, null, json);
        }
    }

    // ---------- DeepSeek ----------
    private static String deepseek(String key, String model, String system, String user, boolean json) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", system));
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        body.put("messages", msgs);
        body.put("temperature", 0.4);
        body.put("max_tokens", 3000);
        body.put("stream", false);
        if (json) body.put("response_format", new JSONObject().put("type", "json_object"));

        String resp = post("https://api.deepseek.com/chat/completions", body.toString(),
                new String[][]{{"Authorization", "Bearer " + key}});
        JSONArray choices = new JSONObject(resp).optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new Exception("Khali uttor elo");
        return choices.getJSONObject(0).getJSONObject("message").optString("content", "");
    }

    // ---------- Gemini ----------
    private static String gemini(String key, String model, String system, String user,
                                 String mime, String base64, boolean json) throws Exception {
        try {
            return geminiOnce(key, model, system, user, mime, base64, json, thinkingParamOk);
        } catch (Exception e) {
            String m = String.valueOf(e.getMessage()).toLowerCase();
            if (thinkingParamOk && m.contains("(400)") && m.contains("think")) {
                thinkingParamOk = false;
                return geminiOnce(key, model, system, user, mime, base64, json, false);
            }
            throw e;
        }
    }

    private static String geminiOnce(String key, String model, String system, String user,
                                     String mime, String base64, boolean json, boolean lowThinking) throws Exception {
        JSONArray parts = new JSONArray();
        if (base64 != null) {
            parts.put(new JSONObject().put("inline_data",
                    new JSONObject().put("mime_type", mime).put("data", base64)));
        }
        parts.put(new JSONObject().put("text", user));

        JSONObject body = new JSONObject();
        body.put("system_instruction", new JSONObject()
                .put("parts", new JSONArray().put(new JSONObject().put("text", system))));
        body.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", parts)));
        JSONObject gen = new JSONObject().put("temperature", 0.4);
        if (json) gen.put("responseMimeType", "application/json");
        if (lowThinking) gen.put("thinkingConfig", new JSONObject().put("thinkingLevel", "low"));
        body.put("generationConfig", gen);

        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
        String resp = post(url, body.toString(), new String[][]{{"x-goog-api-key", key}});
        JSONObject j = new JSONObject(resp);
        JSONArray cands = j.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) {
            JSONObject fb = j.optJSONObject("promptFeedback");
            String reason = fb != null ? fb.optString("blockReason", "") : "";
            throw new Exception(reason.isEmpty() ? "Khali uttor elo" : "Block hoyeche: " + reason);
        }
        JSONObject content = cands.getJSONObject(0).optJSONObject("content");
        JSONArray outParts = content != null ? content.optJSONArray("parts") : null;
        if (outParts == null) throw new Exception("Khali uttor elo");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < outParts.length(); i++) {
            JSONObject part = outParts.getJSONObject(i);
            if (part.optBoolean("thought", false)) continue;
            sb.append(part.optString("text", ""));
        }
        return sb.toString();
    }

    // ---------- JSON ----------
    public static JSONObject parseJson(String raw) {
        if (raw == null) return null;
        int a = raw.indexOf('{'), b = raw.lastIndexOf('}');
        if (a < 0 || b <= a) return null;
        try {
            return new JSONObject(raw.substring(a, b + 1));
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- HTTP ----------
    private static String post(String url, String body, String[][] headers) throws Exception {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("POST");
            con.setConnectTimeout(7000);   // VPN na thakle druto bujhe onnota-y jay
            con.setReadTimeout(60000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            for (String[] h : headers) con.setRequestProperty(h[0], h[1]);
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = con.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? con.getInputStream() : con.getErrorStream();
            String resp = is == null ? "" : readAll(is);
            if (code < 200 || code >= 300) throw new Exception(friendly(code) + " " + shortError(resp));
            return resp;
        } catch (UnknownHostException | SocketTimeoutException | ConnectException
                 | NoRouteToHostException | SSLException e) {
            throw new NetErr(e.getClass().getSimpleName());
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private static String friendly(int code) {
        switch (code) {
            case 400: return "(400) Request bhul / model naam bhul hote pare.";
            case 401:
            case 403: return "(" + code + ") API key bhul ba permission nai.";
            case 402: return "(402) Account-e balance nai.";
            case 404: return "(404) Model naam paoa jay nai.";
            case 429: return "(429) Limit shesh, ektu pore try korun.";
            case 503: return "(HTTP 503) Server byasto.";
            default: return "(HTTP " + code + ")";
        }
    }

    private static String shortError(String resp) {
        try {
            JSONObject j = new JSONObject(resp);
            Object err = j.opt("error");
            if (err instanceof JSONObject) return ((JSONObject) err).optString("message", "");
            if (err != null) return err.toString();
        } catch (Exception ignored) { }
        return resp.length() > 200 ? resp.substring(0, 200) : resp;
    }

    private static String readAll(InputStream is) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }
}
