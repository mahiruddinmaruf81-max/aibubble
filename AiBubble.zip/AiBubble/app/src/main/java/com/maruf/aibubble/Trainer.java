package com.maruf.aibubble;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * "AI shekhano": user-er tottho, reply style, prosno-uttor ar shekha example.
 * Proti reply-r age egulo AI-ke bole deya hoy.
 */
public final class Trainer {

    public static final String ABOUT = "t_about";
    public static final String STYLE = "t_style";       // nijer lekha nirdesh
    public static final String TONES = "t_tones";       // "friendly,short" ityadi
    public static final String QA = "t_qa";             // [[q,a],...]
    public static final String EXAMPLES = "t_examples"; // [[msg,reply],...]
    public static final String LEARN = "t_learn";

    public static final String[][] TONE_LIST = {
            {"friendly", "😊 Friendly", "warm and friendly"},
            {"formal", "🎩 Formal", "polite and formal"},
            {"short", "✂️ Choto", "very short (one sentence)"},
            {"emoji", "🎉 Emoji", "use one or two fitting emojis"},
            {"sales", "🛒 Seller", "like a helpful shop seller who tries to close the sale"},
            {"funny", "😄 Moja", "light and a little funny"},
    };

    private static final int MAX_EXAMPLES = 20;

    private Trainer() {}

    private static SharedPreferences p(Context c) {
        return Prefs.get(c);
    }

    /** Reply prompt-er sheshe jog hoy. */
    public static String context(Context c) {
        SharedPreferences sp = p(c);
        StringBuilder sb = new StringBuilder();

        String about = sp.getString(ABOUT, "").trim();
        if (!about.isEmpty()) {
            sb.append("\n\nFacts about the user and their business (use these when relevant, they are true):\n")
                    .append(about);
        }

        List<String> tones = new ArrayList<>();
        String sel = "," + sp.getString(TONES, "") + ",";
        for (String[] t : TONE_LIST) if (sel.contains("," + t[0] + ",")) tones.add(t[2]);
        String style = sp.getString(STYLE, "").trim();
        if (!tones.isEmpty() || !style.isEmpty()) {
            sb.append("\n\nReply style the user wants: ");
            if (!tones.isEmpty()) sb.append(String.join("; ", tones)).append(". ");
            if (!style.isEmpty()) sb.append(style);
        }

        List<String[]> qa = list(c, QA);
        if (!qa.isEmpty()) {
            sb.append("\n\nFixed answers: if the message asks about one of these, answer with this information "
                    + "(translated to the reply language):");
            int n = 0;
            for (String[] x : qa) {
                if (n++ >= 40) break;
                sb.append("\n- Q: ").append(x[0]).append(" → A: ").append(x[1]);
            }
        }

        List<String[]> ex = list(c, EXAMPLES);
        if (!ex.isEmpty()) {
            sb.append("\n\nExamples of how the user really replies (follow this style and wording):");
            for (int i = Math.max(0, ex.size() - 8); i < ex.size(); i++) {
                sb.append("\n- Message: ").append(cut(ex.get(i)[0], 200))
                        .append("\n  User's reply: ").append(cut(ex.get(i)[1], 200));
            }
        }

        if (sb.length() > 0) {
            sb.append("\n\nOnly use the facts above; do not invent other facts.");
        }
        return sb.toString();
    }

    public static boolean learnOn(Context c) {
        return p(c).getBoolean(LEARN, true);
    }

    /** User AI-er reply bodle pathale example hishebe rakhe. */
    public static void learn(Context c, String msg, String reply) {
        if (msg == null || reply == null) return;
        msg = cut(msg.trim(), 300);
        reply = reply.trim();
        if (msg.isEmpty() || reply.isEmpty()) return;
        List<String[]> ex = list(c, EXAMPLES);
        ex.add(new String[]{msg, reply});
        while (ex.size() > MAX_EXAMPLES) ex.remove(0);
        save(c, EXAMPLES, ex);
    }

    public static List<String[]> list(Context c, String key) {
        List<String[]> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONArray x = a.getJSONArray(i);
                out.add(new String[]{x.optString(0, ""), x.optString(1, "")});
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static void save(Context c, String key, List<String[]> items) {
        JSONArray a = new JSONArray();
        for (String[] x : items) a.put(new JSONArray().put(x[0]).put(x[1]));
        p(c).edit().putString(key, a.toString()).apply();
    }

    private static String cut(String s, int n) {
        if (s == null) return "";
        // shesh-er dik rakhi (notun message shesh-e thake)
        return s.length() <= n ? s : "…" + s.substring(s.length() - n);
    }
}
