package com.maruf.aibubble;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Chhobi load / chhoto kora / save. */
public final class Media {

    private Media() {}

    public static Bitmap scale(Bitmap bm, int maxSide) {
        int w = bm.getWidth(), h = bm.getHeight();
        int big = Math.max(w, h);
        if (big <= maxSide) return bm;
        float f = (float) maxSide / big;
        return Bitmap.createScaledBitmap(bm, Math.max(1, (int) (w * f)), Math.max(1, (int) (h * f)), true);
    }

    /** Gallery / camera-r chhobi, thik dike ghuriye (EXIF), maxSide porjonto chhoto. */
    public static Bitmap loadUri(Context c, Uri uri, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream is = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(is, null, o);
        }
        if (o.outWidth <= 0) throw new Exception("Chhobi khola gelo na");
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxSide) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        Bitmap bm;
        try (InputStream is = c.getContentResolver().openInputStream(uri)) {
            bm = BitmapFactory.decodeStream(is, null, o2);
        }
        if (bm == null) throw new Exception("Chhobi khola gelo na");

        int rotate = 0;
        try (InputStream is = c.getContentResolver().openInputStream(uri)) {
            if (is != null) {
                int ori = new ExifInterface(is).getAttributeInt(ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) rotate = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rotate = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rotate = 270;
            }
        } catch (Exception ignored) { }

        Bitmap scaled = scale(bm, maxSide);
        if (scaled != bm) bm.recycle();
        if (rotate != 0) {
            Matrix m = new Matrix();
            m.postRotate(rotate);
            Bitmap r = Bitmap.createBitmap(scaled, 0, 0, scaled.getWidth(), scaled.getHeight(), m, true);
            if (r != scaled) scaled.recycle();
            return r;
        }
        return scaled;
    }

    /** Majkhan theke kete gol chhobi, shada border soho (bubble-er jonno). */
    public static Bitmap circle(Bitmap src, int size, int border) {
        int s = Math.min(src.getWidth(), src.getHeight());
        Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - s) / 2, (src.getHeight() - s) / 2, s, s);
        Bitmap sc = Bitmap.createScaledBitmap(sq, size, size, true);
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        float r = size / 2f;
        c.drawCircle(r, r, r - border, p);
        Paint b = new Paint(Paint.ANTI_ALIAS_FLAG);
        b.setStyle(Paint.Style.STROKE);
        b.setStrokeWidth(border);
        b.setColor(Color.WHITE);
        c.drawCircle(r, r, r - border / 2f, b);
        return out;
    }

    public static Bitmap loadFile(String path, int maxSide) {
        Bitmap bm = BitmapFactory.decodeFile(path);
        if (bm == null) return null;
        Bitmap s = scale(bm, maxSide);
        if (s != bm) bm.recycle();
        return s;
    }

    public static File saveJpeg(Context c, Bitmap bm, String name) throws Exception {
        File f = new File(c.getCacheDir(), name);
        try (FileOutputStream fos = new FileOutputStream(f)) {
            bm.compress(Bitmap.CompressFormat.JPEG, 90, fos);
        }
        return f;
    }

    public static String fileToB64(String path) throws Exception {
        File f = new File(path);
        byte[] data = new byte[(int) f.length()];
        try (FileInputStream fis = new FileInputStream(f)) {
            int off = 0, n;
            while (off < data.length && (n = fis.read(data, off, data.length - off)) > 0) off += n;
        }
        return Base64.encodeToString(data, Base64.NO_WRAP);
    }
}
