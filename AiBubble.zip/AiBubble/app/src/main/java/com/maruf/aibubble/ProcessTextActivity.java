package com.maruf.aibubble;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/** Text select kore "AI Translate" ba Share → AI Bubble chaple panel-e text niye khule. */
public class ProcessTextActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent in = getIntent();
        CharSequence text = in.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        if (text == null) text = in.getCharSequenceExtra(Intent.EXTRA_TEXT);

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Age AI Bubble app khule bubble chalu korun", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        Intent svc = new Intent(this, FloatingService.class).setAction(FloatingService.ACTION_OPEN);
        if (text != null) svc.putExtra(FloatingService.EXTRA_TEXT, text.toString());
        startForegroundService(svc);
        finish();
    }
}
