package com.maruf.aibubble;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.List;

/** 🧠 AI shekhano: tottho, style, prosno-uttor, shekha example, test. */
public class TrainActivity extends Activity {

    private static final int BG = 0xFFF1F5F9, CARD = 0xFFFFFFFF, TEXT = 0xFF0F172A, SUB = 0xFF64748B;
    private static final int ACCENT = 0xFF2563EB, GREEN = 0xFF16A34A, RED = 0xFFDC2626;

    private EditText about, style, qIn, aIn, testIn;
    private TextView testOut;
    private LinearLayout qaList, exList, toneRow1, toneRow2;
    private String tones;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(18), dp(16), dp(40));
        scroll.addView(box);
        setContentView(scroll);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = pill("←", 0xFFE2E8F0, TEXT);
        back.setOnClickListener(v -> finish());
        head.addView(back);
        TextView title = text("  🧠 AI shekhan", 21, TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(title);
        box.addView(head);
        box.addView(text("Ja likhben, AI proti reply-r age sheta mone rakhbe. Shob kichu phone-ei thake.", 13, SUB),
                top(dp(8)));

        // 1. Tottho
        LinearLayout c1 = card(box, "Apnar / business-er tottho");
        c1.addView(text("Naam, ki kaj koren, dokan, product, dam, delivery, thikana, shomoy… "
                + "AI shudhu ei tottho use korbe, nije dam/tarikh banabe na.", 12, SUB));
        about = area("Jemon:\nAmar naam Maruf. Ami Guangzhou theke electronics pathai.\n"
                + "Delivery Bangladesh-e 10-15 din.\nPayment: Alipay / bKash.", 5);
        about.setText(Prefs.get(this).getString(Trainer.ABOUT, ""));
        c1.addView(about, top(dp(8)));

        // 2. Style
        LinearLayout c2 = card(box, "Kemon kore reply dibe");
        tones = Prefs.get(this).getString(Trainer.TONES, "friendly");
        toneRow1 = new LinearLayout(this);
        toneRow2 = new LinearLayout(this);
        for (int i = 0; i < Trainer.TONE_LIST.length; i++) {
            final String code = Trainer.TONE_LIST[i][0];
            TextView chip = pill(Trainer.TONE_LIST[i][1], BG, TEXT);
            chip.setTag(code);
            chip.setOnClickListener(v -> toggleTone(code));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            (i < 3 ? toneRow1 : toneRow2).addView(chip, lp);
        }
        c2.addView(toneRow1, top(dp(4)));
        c2.addView(toneRow2);
        refreshTones();
        style = area("Nijer nirdesh (optional), jemon:\nCustomer-ke \"bhai\" bolo. Chinese-e shob shomoy 您 use koro.", 3);
        style.setText(Prefs.get(this).getString(Trainer.STYLE, ""));
        c2.addView(style, top(dp(8)));

        // 3. Prosno -> uttor
        LinearLayout c3 = card(box, "Prosno → Uttor");
        c3.addView(text("Customer ei prosno korle AI ei uttor dibe (je bhashay dorkar, translate kore).", 12, SUB));
        qIn = line("Prosno, jemon: dam koto / 多少钱");
        c3.addView(qIn, top(dp(8)));
        aIn = line("Uttor, jemon: 500 yuan, free delivery");
        c3.addView(aIn, top(dp(6)));
        TextView add = pill("＋  Jog korun", ACCENT, Color.WHITE);
        add.setOnClickListener(v -> addQa());
        c3.addView(add, top(dp(8), dp(42)));
        qaList = new LinearLayout(this);
        qaList.setOrientation(LinearLayout.VERTICAL);
        c3.addView(qaList, top(dp(6)));
        renderQa();

        // 4. Shekha example
        LinearLayout c4 = card(box, "Nije nije shekha");
        CheckBox learn = new CheckBox(this);
        learn.setText("Ami AI-er reply bodle pathale sheta shikho");
        learn.setTextColor(TEXT);
        learn.setChecked(Trainer.learnOn(this));
        learn.setOnCheckedChangeListener((cb, on) -> Prefs.get(this).edit().putBoolean(Trainer.LEARN, on).apply());
        c4.addView(learn);
        c4.addView(text("Shesh 20-ta example rakhe. Bhul hole muche din.", 12, SUB));
        exList = new LinearLayout(this);
        exList.setOrientation(LinearLayout.VERTICAL);
        c4.addView(exList, top(dp(6)));
        renderExamples();

        // Save
        TextView save = pill("💾  Save korun", TEXT, Color.WHITE);
        save.setTypeface(Typeface.DEFAULT_BOLD);
        save.setOnClickListener(v -> {
            save();
            toast("Save hoyeche. Ekhon theke AI ei moto reply dibe.");
        });
        box.addView(save, top(dp(16), dp(50)));

        // 5. Test
        LinearLayout c5 = card(box, "Test korun");
        testIn = area("Customer-er message likhun, jemon: 你好，这个多少钱？", 2);
        c5.addView(testIn, top(dp(4)));
        TextView test = pill("💬  AI ki reply dey dekhi", GREEN, Color.WHITE);
        test.setOnClickListener(v -> runTest());
        c5.addView(test, top(dp(8), dp(44)));
        testOut = text("", 14, TEXT);
        testOut.setTextIsSelectable(true);
        c5.addView(testOut, top(dp(8)));
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }

    private void save() {
        Prefs.get(this).edit()
                .putString(Trainer.ABOUT, about.getText().toString().trim())
                .putString(Trainer.STYLE, style.getText().toString().trim())
                .putString(Trainer.TONES, tones)
                .apply();
    }

    private void toggleTone(String code) {
        String s = "," + tones + ",";
        if (s.contains("," + code + ",")) s = s.replace("," + code + ",", ",");
        else s = s + code + ",";
        tones = s.replaceAll("^,+|,+$", "").replaceAll(",,+", ",");
        refreshTones();
    }

    private void refreshTones() {
        String s = "," + tones + ",";
        for (LinearLayout r : new LinearLayout[]{toneRow1, toneRow2}) {
            for (int i = 0; i < r.getChildCount(); i++) {
                TextView t = (TextView) r.getChildAt(i);
                boolean on = s.contains("," + t.getTag() + ",");
                t.setBackground(round(on ? TEXT : BG, dp(19)));
                t.setTextColor(on ? Color.WHITE : TEXT);
            }
        }
    }

    private void addQa() {
        String q = qIn.getText().toString().trim(), a = aIn.getText().toString().trim();
        if (q.isEmpty() || a.isEmpty()) {
            toast("Prosno ar uttor duitai likhun");
            return;
        }
        List<String[]> l = Trainer.list(this, Trainer.QA);
        l.add(new String[]{q, a});
        Trainer.save(this, Trainer.QA, l);
        qIn.setText("");
        aIn.setText("");
        renderQa();
        toast("Jog hoyeche");
    }

    private void renderQa() {
        qaList.removeAllViews();
        List<String[]> l = Trainer.list(this, Trainer.QA);
        if (l.isEmpty()) {
            qaList.addView(text("Ekhono kichu nai", 12, SUB));
            return;
        }
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            qaList.addView(itemRow("❓ " + l.get(i)[0], "💬 " + l.get(i)[1], () -> {
                List<String[]> cur = Trainer.list(this, Trainer.QA);
                if (idx < cur.size()) cur.remove(idx);
                Trainer.save(this, Trainer.QA, cur);
                renderQa();
            }), top(dp(6)));
        }
    }

    private void renderExamples() {
        exList.removeAllViews();
        List<String[]> l = Trainer.list(this, Trainer.EXAMPLES);
        if (l.isEmpty()) {
            exList.addView(text("Ekhono kichu shekhe nai. Panel-e reply edit kore Send korle ekhane ashbe.", 12, SUB));
            return;
        }
        for (int i = l.size() - 1; i >= 0; i--) {
            final int idx = i;
            exList.addView(itemRow("🗨 " + l.get(i)[0], "✍️ " + l.get(i)[1], () -> {
                List<String[]> cur = Trainer.list(this, Trainer.EXAMPLES);
                if (idx < cur.size()) cur.remove(idx);
                Trainer.save(this, Trainer.EXAMPLES, cur);
                renderExamples();
            }), top(dp(6)));
        }
    }

    private View itemRow(String a, String b, Runnable onDelete) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(8), dp(6), dp(8));
        r.setBackground(round(BG, dp(12)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = text(a, 13, SUB);
        t1.setMaxLines(2);
        TextView t2 = text(b, 14, TEXT);
        t2.setMaxLines(3);
        col.addView(t1);
        col.addView(t2);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView del = text("🗑", 18, RED);
        del.setPadding(dp(10), dp(4), dp(6), dp(4));
        del.setOnClickListener(v -> onDelete.run());
        r.addView(del);
        return r;
    }

    private void runTest() {
        save();
        final String msg = testIn.getText().toString().trim();
        if (msg.isEmpty()) {
            toast("Age ekta message likhun");
            return;
        }
        testOut.setTextColor(SUB);
        testOut.setText("⏳ Reply banacchi…");
        final String sys = "You help the user reply to chat messages. The input is a message the user RECEIVED. "
                + "Return ONLY a JSON object: {\"meaning\": a short Bengali (Bangla script) translation of the message, "
                + "\"reply\": ONE short, natural reply the user can send, in the same language the other person wrote in}."
                + Trainer.context(this);
        new Thread(() -> {
            String out;
            int color;
            try {
                String[] r = AiClient.ask(getApplicationContext(), sys, msg, true);
                JSONObject j = AiClient.parseJson(r[0]);
                String meaning = j != null ? j.optString("meaning", "") : "";
                String reply = j != null ? j.optString("reply", r[0]) : r[0];
                out = (meaning.isEmpty() ? "" : "🗨 " + meaning + "\n\n") + "💬 " + reply + "\n\n(" + r[1] + ")";
                color = TEXT;
            } catch (Exception e) {
                out = "❌ " + e.getMessage();
                color = RED;
            }
            final String o = out;
            final int c = color;
            runOnUiThread(() -> {
                testOut.setText(o);
                testOut.setTextColor(c);
            });
        }).start();
    }

    // ---------- ui ----------

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(round(CARD, dp(18)));
        TextView t = text(title, 16, TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, 0, 0, dp(4));
        c.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        parent.addView(c, lp);
        return c;
    }

    private EditText area(String hint, int lines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setMinLines(lines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        e.setTextColor(TEXT);
        e.setHintTextColor(0xFF94A3B8);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable d = round(0xFFF8FAFC, dp(12));
        d.setStroke(dp(1), 0xFFE2E8F0);
        e.setBackground(d);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        return e;
    }

    private EditText line(String hint) {
        EditText e = area(hint, 1);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        return e;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.2f);
        return t;
    }

    private TextView pill(String s, int bg, int fg) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(fg);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        t.setBackground(round(bg, dp(20)));
        return t;
    }

    private GradientDrawable round(int color, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(r);
        return d;
    }

    private LinearLayout.LayoutParams top(int m) {
        return top(m, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams top(int m, int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h);
        lp.topMargin = m;
        return lp;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
