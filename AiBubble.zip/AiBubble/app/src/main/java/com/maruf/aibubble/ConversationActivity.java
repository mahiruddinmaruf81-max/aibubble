package com.maruf.aibubble;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Live voice translate: duita bhasha select kore, je dik theke bolben shei mic chapun.
 * Bolar shomoy lekha live dekhay, tarpor onno bhashay translate kore jore shonay.
 * Phone-e speech engine na thakle (ba kaj na korle) record kore Gemini diye bujhe.
 */
public class ConversationActivity extends Activity {

    public static final String EXTRA_FOR_PANEL = "for_panel";

    /** label, speech tag, AI-er jonno naam */
    static final String[][] LANGS = {
            {"বাংলা", "bn-BD", "Bengali (Bangla script)"},
            {"English", "en-US", "English"},
            {"中文", "zh-CN", "Simplified Chinese"},
            {"हिन्दी", "hi-IN", "Hindi"},
            {"اردو", "ur-PK", "Urdu"},
            {"العربية", "ar-SA", "Arabic"},
            {"日本語", "ja-JP", "Japanese"},
            {"한국어", "ko-KR", "Korean"},
            {"Melayu", "ms-MY", "Malay"},
            {"Русский", "ru-RU", "Russian"},
    };

    private static final int A_COLOR = 0xFF2563EB, B_COLOR = 0xFF16A34A;
    private static final int REQ_MIC = 21;

    private final Handler main = new Handler(Looper.getMainLooper());
    private Spinner spA, spB;
    private LinearLayout list;
    private ScrollView scroll;
    private TextView live, micA, micB, speakChip, engineChip, useBtn;
    private ObjectAnimator pulse;

    private SpeechRecognizer sr;
    private MediaRecorder rec;
    private File recFile;
    private int listeningSide = -1;   // 0 = A, 1 = B
    private int pendingSide = -1;
    private boolean useGemini;        // phone engine-er bodole Gemini
    private boolean autoSpeak;
    private boolean forPanel;
    private String lastOriginal, lastTranslation;

    private TextToSpeech tts;
    private boolean ttsReady;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        forPanel = getIntent().getBooleanExtra(EXTRA_FOR_PANEL, false);
        autoSpeak = Prefs.get(this).getBoolean("conv_speak", true);
        boolean phoneEngine = SpeechRecognizer.isRecognitionAvailable(this);
        useGemini = Prefs.get(this).getBoolean("conv_gemini", !phoneEngine);
        if (!phoneEngine) useGemini = true;

        LinearLayout rootCol = new LinearLayout(this);
        rootCol.setOrientation(LinearLayout.VERTICAL);
        rootCol.setBackgroundColor(0xFFF1F5F9);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(12), dp(14), dp(8));
        TextView back = chip("✕", 0xFFE2E8F0, 0xFF0F172A);
        back.setOnClickListener(v -> finish());
        header.addView(back);
        TextView title = new TextView(this);
        title.setText("  Live voice translate");
        title.setTextColor(0xFF0F172A);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        speakChip = chip("", 0xFFE2E8F0, 0xFF0F172A);
        speakChip.setOnClickListener(v -> {
            autoSpeak = !autoSpeak;
            Prefs.get(this).edit().putBoolean("conv_speak", autoSpeak).apply();
            refreshChips();
        });
        header.addView(speakChip);
        engineChip = chip("", 0xFFE2E8F0, 0xFF0F172A);
        engineChip.setOnClickListener(v -> {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                toast("Phone-e speech engine nai, Gemini-i use hobe");
                return;
            }
            useGemini = !useGemini;
            Prefs.get(this).edit().putBoolean("conv_gemini", useGemini).apply();
            refreshChips();
        });
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-2, -2);
        elp.leftMargin = dp(6);
        header.addView(engineChip, elp);
        rootCol.addView(header);

        // Bhasha select
        LinearLayout langRow = new LinearLayout(this);
        langRow.setGravity(Gravity.CENTER_VERTICAL);
        langRow.setPadding(dp(14), 0, dp(14), dp(8));
        spA = spinner(Prefs.get(this).getInt("conv_a", 0));
        spB = spinner(Prefs.get(this).getInt("conv_b", 2));
        TextView swap = chip("⇄", Color.WHITE, 0xFF0F172A);
        swap.setOnClickListener(v -> {
            int a = spA.getSelectedItemPosition();
            spA.setSelection(spB.getSelectedItemPosition());
            spB.setSelection(a);
        });
        langRow.addView(spA, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.setMargins(dp(8), 0, dp(8), 0);
        langRow.addView(swap, slp);
        langRow.addView(spB, new LinearLayout.LayoutParams(0, dp(46), 1f));
        rootCol.addView(langRow);

        // Kotha-r list
        scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(4), dp(14), dp(8));
        scroll.addView(list);
        rootCol.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView hint = new TextView(this);
        hint.setText("Je bhashay bolben, nicher shei mic chapun. Bola shesh hole abar chapun (ba chup thakun).");
        hint.setTextColor(0xFF64748B);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(10), dp(30), dp(10), dp(10));
        list.addView(hint);

        // Live lekha
        live = new TextView(this);
        live.setTextColor(0xFF475569);
        live.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        live.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
        live.setGravity(Gravity.CENTER);
        live.setPadding(dp(16), dp(6), dp(16), dp(6));
        rootCol.addView(live);

        // Mic button
        LinearLayout mics = new LinearLayout(this);
        mics.setGravity(Gravity.CENTER);
        mics.setPadding(dp(14), dp(6), dp(14), dp(14));
        micA = micButton(A_COLOR);
        micA.setOnClickListener(v -> onMic(0));
        micB = micButton(B_COLOR);
        micB.setOnClickListener(v -> onMic(1));
        FrameLayout fa = new FrameLayout(this);
        fa.addView(micA, new FrameLayout.LayoutParams(-1, dp(64)));
        FrameLayout fb = new FrameLayout(this);
        fb.addView(micB, new FrameLayout.LayoutParams(-1, dp(64)));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, -2, 1f);
        mlp.setMargins(dp(5), 0, dp(5), 0);
        mics.addView(fa, mlp);
        LinearLayout.LayoutParams mlp2 = new LinearLayout.LayoutParams(0, -2, 1f);
        mlp2.setMargins(dp(5), 0, dp(5), 0);
        mics.addView(fb, mlp2);
        rootCol.addView(mics);

        if (forPanel) {
            useBtn = chip("✓  Ei translation panel-e nao", 0xFF7C3AED, Color.WHITE);
            useBtn.setGravity(Gravity.CENTER);
            useBtn.setOnClickListener(v -> usePanel());
            LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(-1, dp(48));
            ulp.setMargins(dp(19), 0, dp(19), dp(14));
            rootCol.addView(useBtn, ulp);
            useBtn.setVisibility(View.GONE);
        }

        setContentView(rootCol);
        refreshChips();
        refreshMics();

        AdapterView.OnItemSelectedListener l = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                Prefs.get(ConversationActivity.this).edit()
                        .putInt("conv_a", spA.getSelectedItemPosition())
                        .putInt("conv_b", spB.getSelectedItemPosition()).apply();
                refreshMics();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) { }
        };
        spA.setOnItemSelectedListener(l);
        spB.setOnItemSelectedListener(l);

        tts = new TextToSpeech(getApplicationContext(), st -> ttsReady = st == TextToSpeech.SUCCESS);
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopAll(false);
    }

    @Override
    protected void onDestroy() {
        stopAll(false);
        if (sr != null) {
            sr.destroy();
            sr = null;
        }
        if (tts != null) tts.shutdown();
        FloatingService fs = FloatingService.instance;
        if (fs != null) fs.showBubbleLater();
        super.onDestroy();
    }

    // ------------------------------------------------------------- mic

    private void onMic(int side) {
        if (listeningSide == side) {
            // abar chaple shesh
            if (useGemini) stopRecording(true);
            else if (sr != null) sr.stopListening();
            return;
        }
        if (listeningSide != -1) stopAll(false);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingSide = side;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (useGemini) startRecording(side);
        else startPhoneEngine(side);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_MIC && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pendingSide >= 0) {
            int s = pendingSide;
            pendingSide = -1;
            onMic(s);
        } else if (req == REQ_MIC) {
            toast("Mic permission chara voice kaj korbe na");
        }
    }

    private void startPhoneEngine(final int side) {
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { live.setText("🎙 Bolun…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { live.setText("⏳ Bujhchi…"); }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onPartialResults(Bundle r) {
                    String s = first(r);
                    if (s != null && !s.isEmpty()) live.setText(s);
                }

                @Override
                public void onResults(Bundle r) {
                    int sd = listeningSide;
                    setListening(-1);
                    String s = first(r);
                    if (s == null || s.trim().isEmpty()) {
                        live.setText("Kichu shona jay nai, abar chapun");
                        return;
                    }
                    live.setText("");
                    translate(sd, s.trim());
                }

                @Override
                public void onError(int error) {
                    setListening(-1);
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        live.setText("Kichu shona jay nai, abar chapun");
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                            || error == SpeechRecognizer.ERROR_SERVER || error == SpeechRecognizer.ERROR_CLIENT
                            || (Build.VERSION.SDK_INT >= 31 && error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED)
                            || (Build.VERSION.SDK_INT >= 31 && error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
                        live.setText("Phone-er voice engine kaj korche na (" + error + "). Upore \"Engine\" chepe Gemini korun.");
                    } else {
                        live.setText("Voice error (" + error + "), abar chapun");
                    }
                }
            });
        }
        String tag = LANGS[langIndex(side)][1];
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try {
            sr.startListening(i);
            setListening(side);
            live.setText("🎙 Bolun…");
        } catch (Exception e) {
            live.setText("Voice shuru kora gelo na: " + e.getMessage());
        }
    }

    private static String first(Bundle r) {
        ArrayList<String> l = r == null ? null : r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (l == null || l.isEmpty()) ? null : l.get(0);
    }

    private void startRecording(int side) {
        if (!Prefs.hasGemini(this)) {
            live.setText("Gemini key nai. Setting-e Gemini key din, ba phone-er voice engine use korun.");
            return;
        }
        try {
            recFile = new File(getCacheDir(), "voice.m4a");
            rec = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            rec.setAudioSource(MediaRecorder.AudioSource.MIC);
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            rec.setAudioSamplingRate(16000);
            rec.setAudioEncodingBitRate(32000);
            rec.setAudioChannels(1);
            rec.setMaxDuration(60000);
            rec.setOnInfoListener((mr, what, extra) -> {
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) stopRecording(true);
            });
            rec.setOutputFile(recFile.getAbsolutePath());
            rec.prepare();
            rec.start();
            setListening(side);
            live.setText("🎙 Bolun… shesh hole mic abar chapun");
        } catch (Exception e) {
            releaseRec();
            live.setText("Mic chalu hocche na: " + e.getMessage());
        }
    }

    private void stopRecording(boolean send) {
        int side = listeningSide;
        boolean ok = false;
        if (rec != null) {
            try {
                rec.stop();
                ok = true;
            } catch (Exception ignored) { }
            releaseRec();
        }
        setListening(-1);
        if (!send) return;
        if (!ok || recFile == null || recFile.length() < 1500) {
            live.setText("Kichu record hoy nai, abar chapun");
            return;
        }
        live.setText("⏳ Gemini shunche…");
        final int from = langIndex(side), to = langIndex(1 - side);
        final String path = recFile.getAbsolutePath();
        new Thread(() -> {
            try {
                String b64 = Media.fileToB64(path);
                String system = "The audio is a person speaking " + LANGS[from][2]
                        + " (it may contain some other languages). Return ONLY JSON: "
                        + "{\"text\": exact transcription in the original language and script, "
                        + "\"translation\": the text translated into " + LANGS[to][2] + "}.";
                String[] r = AiClient.askMedia(getApplicationContext(), system,
                        "Transcribe and translate this audio.", "audio/mp4", b64, true);
                JSONObject j = AiClient.parseJson(r[0]);
                String text = j != null ? j.optString("text", "") : "";
                String tr = j != null ? j.optString("translation", r[0]) : r[0];
                main.post(() -> {
                    live.setText("");
                    addCard(side, text, tr);
                });
            } catch (Exception e) {
                main.post(() -> live.setText("❌ " + e.getMessage()));
            }
        }).start();
    }

    private void releaseRec() {
        if (rec != null) {
            try { rec.release(); } catch (Exception ignored) { }
            rec = null;
        }
    }

    private void stopAll(boolean send) {
        if (rec != null) stopRecording(send);
        if (sr != null && listeningSide != -1) {
            try { sr.cancel(); } catch (Exception ignored) { }
        }
        setListening(-1);
    }

    // ------------------------------------------------------------- translate

    private void translate(final int side, final String text) {
        final int from = langIndex(side), to = langIndex(1 - side);
        final TextView[] card = addCard(side, text, "⏳ …");
        new Thread(() -> {
            try {
                String system = "Translate the user's text from " + LANGS[from][2] + " into " + LANGS[to][2]
                        + ". It is spoken conversation, so keep it natural and short. Output ONLY the translation.";
                String[] r = AiClient.ask(getApplicationContext(), system, text);
                main.post(() -> {
                    card[1].setText(r[0]);
                    lastOriginal = text;
                    lastTranslation = r[0];
                    if (useBtn != null) useBtn.setVisibility(View.VISIBLE);
                    if (autoSpeak) speak(r[0], LANGS[to][1]);
                });
            } catch (Exception e) {
                main.post(() -> card[1].setText("❌ " + e.getMessage()));
            }
        }).start();
    }

    /** @return [original, translation] TextView */
    private TextView[] addCard(int side, String original, String translation) {
        if (list.getChildCount() == 1 && list.getChildAt(0) instanceof TextView
                && ((TextView) list.getChildAt(0)).getText().toString().startsWith("Je bhashay")) {
            list.removeAllViews();
        }
        int color = side == 0 ? A_COLOR : B_COLOR;
        int to = langIndex(1 - side);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(10), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(2), (color & 0x00FFFFFF) | 0x55000000);
        c.setBackground(bg);

        TextView o = new TextView(this);
        o.setText(original);
        o.setTextColor(0xFF64748B);
        o.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        c.addView(o);
        TextView t = new TextView(this);
        t.setText(translation);
        t.setTextColor(0xFF0F172A);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(4), 0, 0);
        t.setTextIsSelectable(true);
        c.addView(t);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.END);
        actions.setPadding(0, dp(6), 0, 0);
        TextView sp = chip("🔊", 0xFFF1F5F9, 0xFF0F172A);
        sp.setOnClickListener(v -> speak(t.getText().toString(), LANGS[to][1]));
        TextView cp = chip("⧉", 0xFFF1F5F9, 0xFF0F172A);
        cp.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("AI Bubble", t.getText()));
            toast("Copy hoyeche");
        });
        actions.addView(sp);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.leftMargin = dp(6);
        actions.addView(cp, alp);
        c.addView(actions);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        if (side == 0) lp.rightMargin = dp(30); else lp.leftMargin = dp(30);
        list.addView(c, lp);
        c.setAlpha(0f);
        c.setTranslationY(dp(20));
        c.animate().alpha(1f).translationY(0).setDuration(220).start();
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        return new TextView[]{o, t};
    }

    private void speak(String s, String tag) {
        if (tts == null || !ttsReady) {
            toast("Text-to-speech ready na");
            return;
        }
        int r = tts.setLanguage(Locale.forLanguageTag(tag));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            toast("Ei bhashar voice phone-e nai (Settings → Text-to-speech)");
            return;
        }
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "conv");
    }

    private void usePanel() {
        if (lastTranslation == null) return;
        FloatingService fs = FloatingService.instance;
        if (fs != null) fs.receiveText(lastOriginal, lastTranslation);
        finish();
    }

    // ------------------------------------------------------------- ui

    private int langIndex(int side) {
        return side == 0 ? spA.getSelectedItemPosition() : spB.getSelectedItemPosition();
    }

    private void setListening(int side) {
        listeningSide = side;
        refreshMics();
        if (pulse != null) {
            pulse.cancel();
            pulse = null;
        }
        micA.setScaleX(1f);
        micA.setScaleY(1f);
        micB.setScaleX(1f);
        micB.setScaleY(1f);
        if (side >= 0) {
            View v = side == 0 ? micA : micB;
            pulse = ObjectAnimator.ofPropertyValuesHolder(v,
                    PropertyValuesHolder.ofFloat("scaleX", 1f, 1.05f),
                    PropertyValuesHolder.ofFloat("scaleY", 1f, 1.05f));
            pulse.setDuration(500);
            pulse.setRepeatCount(ValueAnimator.INFINITE);
            pulse.setRepeatMode(ValueAnimator.REVERSE);
            pulse.start();
        }
    }

    private void refreshMics() {
        if (micA == null || spA == null) return;
        micA.setText((listeningSide == 0 ? "■  " : "🎤  ") + LANGS[spA.getSelectedItemPosition()][0]);
        micB.setText((listeningSide == 1 ? "■  " : "🎤  ") + LANGS[spB.getSelectedItemPosition()][0]);
        micA.setBackground(round(listeningSide == 0 ? 0xFFDC2626 : A_COLOR, dp(32)));
        micB.setBackground(round(listeningSide == 1 ? 0xFFDC2626 : B_COLOR, dp(32)));
    }

    private void refreshChips() {
        speakChip.setText(autoSpeak ? "🔊 On" : "🔇 Off");
        engineChip.setText(useGemini ? "Engine: Gemini" : "Engine: Phone");
    }

    private Spinner spinner(int sel) {
        Spinner s = new Spinner(this);
        String[] labels = new String[LANGS.length];
        for (int i = 0; i < LANGS.length; i++) labels[i] = LANGS[i][0];
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(ad);
        s.setSelection(Math.max(0, Math.min(LANGS.length - 1, sel)));
        s.setBackground(round(Color.WHITE, dp(12)));
        s.setPadding(dp(10), 0, dp(10), 0);
        return s;
    }

    private TextView micButton(int color) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(color, dp(32)));
        return t;
    }

    private TextView chip(String s, int bg, int fg) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(fg);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        t.setBackground(round(bg, dp(18)));
        return t;
    }

    private GradientDrawable round(int color, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(r);
        return d;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
