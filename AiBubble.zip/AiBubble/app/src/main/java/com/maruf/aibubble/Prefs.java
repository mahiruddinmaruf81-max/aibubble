package com.maruf.aibubble;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

public final class Prefs {
    public static final String PROVIDER = "provider";       // "deepseek" ba "gemini"
    public static final String DS_KEY = "ds_key";
    public static final String DS_MODEL = "ds_model";
    public static final String GM_KEY = "gm_key";
    public static final String GM_MODEL = "gm_model";
    public static final String LANG = "lang2";              // "auto", "bn", "en", "zh"
    public static final String AUTO_READ = "auto_read";     // bubble chaplei screen pore reply
    public static final String AUTO_POPUP = "auto_popup";   // message ashle popup
    public static final String AUTO_SEND = "auto_send";     // message ashle nije nije reply pathano

    public static final String DEFAULT_DS_MODEL = "deepseek-chat";
    public static final String DEFAULT_GM_MODEL = "gemini-3.8-flash";

    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences("aibubble", Context.MODE_PRIVATE);
    }

    /** "auto" (je kaj kore), "deepseek" ba "gemini" */
    public static String provider(Context c) {
        return get(c).getString(PROVIDER, "auto");
    }

    public static String providerLabel(String p) {
        if ("gemini".equals(p)) return "Gemini";
        if ("deepseek".equals(p)) return "DeepSeek";
        return "Auto";
    }

    public static boolean hasGemini(Context c) {
        return !get(c).getString(GM_KEY, "").trim().isEmpty();
    }

    public static boolean hasAnyKey(Context c) {
        return hasGemini(c) || !get(c).getString(DS_KEY, "").trim().isEmpty();
    }

    /** Settings-e service chalu kora ache kina (process cholche kina alada kotha). */
    public static boolean a11yEnabledInSettings(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(c.getPackageName());
    }

    public static boolean notifAccessEnabled(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(c.getPackageName());
    }
}
