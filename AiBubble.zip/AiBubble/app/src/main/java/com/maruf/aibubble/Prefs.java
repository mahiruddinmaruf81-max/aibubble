package com.maruf.aibubble;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final String PROVIDER = "provider";       // "deepseek" ba "gemini"
    public static final String DS_KEY = "ds_key";
    public static final String DS_MODEL = "ds_model";
    public static final String GM_KEY = "gm_key";
    public static final String GM_MODEL = "gm_model";
    public static final String LANG = "lang";               // "bn", "en", "zh"
    public static final String AUTO_READ = "auto_read";     // bubble chaplei screen pore reply

    public static final String DEFAULT_DS_MODEL = "deepseek-chat";
    public static final String DEFAULT_GM_MODEL = "gemini-2.5-flash";

    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences("aibubble", Context.MODE_PRIVATE);
    }

    public static String provider(Context c) {
        return get(c).getString(PROVIDER, "deepseek");
    }

    public static String providerLabel(String p) {
        return "gemini".equals(p) ? "Gemini" : "DeepSeek";
    }
}
