package com.maruf.aibubble;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Accessibility service: shudhu bubble chaple tokhon screen-e dekha jawa
 * chat-er lekha pore. Background-e kichu pore na, kothao pathay na.
 */
public class ScreenReaderService extends AccessibilityService {

    private static volatile ScreenReaderService instance;

    public static boolean isOn() {
        return instance != null;
    }

    /** Screen-er chat lekha (upor theke niche). Service off thakle null. */
    public static String readChat() {
        ScreenReaderService s = instance;
        if (s == null) return null;
        try {
            return s.read();
        } catch (Exception e) {
            return null;
        }
    }

    public interface ShotCallback {
        /** Screen-er chhobi (software bitmap), ba fail hole null. Main thread-e ashe. */
        void onShot(Bitmap shot);
    }

    /** Screenshot newa jabe kina (Android 11+ ar service chalu). */
    public static boolean canShot() {
        return instance != null && Build.VERSION.SDK_INT >= 30;
    }

    public static void takeShot(ShotCallback cb) {
        ScreenReaderService s = instance;
        if (s == null || Build.VERSION.SDK_INT < 30) {
            cb.onShot(null);
            return;
        }
        try {
            s.shot(cb);
        } catch (Exception e) {
            cb.onShot(null);
        }
    }

    private void shot(final ShotCallback cb) {
        final Handler main = new Handler(Looper.getMainLooper());
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult r) {
                new Thread(() -> {
                    Bitmap sw = null;
                    try {
                        HardwareBuffer hb = r.getHardwareBuffer();
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                        if (hw != null) {
                            sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                            hw.recycle();
                        }
                        hb.close();
                    } catch (Exception ignored) { }
                    final Bitmap out = sw;
                    main.post(() -> cb.onShot(out));
                }).start();
            }

            @Override
            public void onFailure(int errorCode) {
                main.post(() -> cb.onShot(null));
            }
        });
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Kichu kori na: shudhu bubble chaple read() call hoy.
    }

    @Override
    public void onInterrupt() { }

    private static final class Item {
        final int top, left;
        final String text;

        Item(int top, int left, String text) {
            this.top = top;
            this.left = left;
            this.text = text;
        }
    }

    private String read() {
        AccessibilityNodeInfo root = findChatWindowRoot();
        if (root == null) return null;

        List<Item> items = new ArrayList<>();
        collect(root, items, 0);
        Collections.sort(items, (a, b) -> a.top != b.top ? Integer.compare(a.top, b.top)
                : Integer.compare(a.left, b.left));

        List<String> lines = new ArrayList<>();
        for (Item it : items) {
            if (!lines.isEmpty() && lines.get(lines.size() - 1).equals(it.text)) continue;
            lines.add(it.text);
        }
        // Shesher dike notun message thake, tai shesh 40 line rakhi
        int from = Math.max(0, lines.size() - 40);
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < lines.size(); i++) sb.append(lines.get(i)).append('\n');
        String out = sb.toString().trim();
        if (out.length() > 3500) out = out.substring(out.length() - 3500);
        return out;
    }

    /** Amader nijer bubble/panel bade, shobcheye boro app window (jemon Messenger). */
    private AccessibilityNodeInfo findChatWindowRoot() {
        String me = getPackageName();
        AccessibilityNodeInfo best = null;
        long bestArea = -1;
        boolean bestActive = false;
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null) {
            for (AccessibilityWindowInfo w : windows) {
                if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                AccessibilityNodeInfo r = w.getRoot();
                if (r == null) continue;
                CharSequence pkg = r.getPackageName();
                if (pkg != null && me.contentEquals(pkg)) continue;
                Rect b = new Rect();
                w.getBoundsInScreen(b);
                long area = (long) b.width() * b.height();
                boolean active = w.isActive() || w.isFocused();
                if (best == null || (active && !bestActive) || (active == bestActive && area > bestArea)) {
                    best = r;
                    bestArea = area;
                    bestActive = active;
                }
            }
        }
        if (best == null) {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null && (r.getPackageName() == null || !me.contentEquals(r.getPackageName()))) best = r;
        }
        return best;
    }

    private void collect(AccessibilityNodeInfo node, List<Item> out, int depth) {
        if (node == null || depth > 80 || out.size() > 600) return;
        if (!node.isVisibleToUser()) return;
        if (!node.isEditable()) { // lekhar box (draft) bade
            CharSequence t = node.getText();
            if (t == null || t.toString().trim().isEmpty()) t = node.getContentDescription();
            if (t != null) {
                String s = t.toString().trim().replace('\n', ' ');
                if (!s.isEmpty() && s.length() <= 1500) {
                    Rect r = new Rect();
                    node.getBoundsInScreen(r);
                    out.add(new Item(r.top, r.left, s));
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collect(node.getChild(i), out, depth + 1);
        }
    }
}
